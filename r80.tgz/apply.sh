set -e
S=_hv_export_c3cafe373629b93c/stage-r80; B=_hv_export_c3cafe373629b93c/backup-r80; P=_hv_export_c3cafe373629b93c/stage-r78/patcher.php
mkdir -p $B; cp ac-core/public.php assets/interactive/ix.js assets/interactive/ix.css ix-core/lib.php assets/cta/hv-bf.js $B/
php $P ac-core/public.php $S/pub.json --dry; php $P assets/interactive/ix.js $S/ixjs.json --dry; php $P ix-core/lib.php $S/ixlib.json --dry
php -l $S/checkout.php
cp $S/checkout.php ac-core/checkout.php; cp $S/hv-bf.js assets/cta/hv-bf.js
php $P ac-core/public.php $S/pub.json; php $P assets/interactive/ix.js $S/ixjs.json; php $P ix-core/lib.php $S/ixlib.json
grep -q 'r80: premium upsell' assets/interactive/ix.css || cat $S/ixcss.txt >> assets/interactive/ix.css
php -l ac-core/public.php; php -l ix-core/lib.php; echo APPLIED
