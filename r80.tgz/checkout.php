<?php
/* =====================================================================
 * Quick checkout (r80, 25 Nov 2026): /account/checkout/?plan=<key>&back=<page>
 * One screen: the plan, what it includes, and a short form (name + email, or Google).
 * A new visitor gets an account made for them and is signed in; the order is created and
 * they go straight to the UPI payment page. A link to set a password is emailed, so no
 * password is asked for here. Existing emails must sign in (we never act on someone
 * else's account). Signed-in members skip the form.
 * ===================================================================== */
function ac_checkout_plans(PDO $pdo){
    $out = []; foreach (mp_plans($pdo) as $k => $p) if ($k !== 'free' && (int)$p['price'] > 0) $out[$k] = $p;
    return $out;
}
function ac_checkout_go(PDO $pdo, array $m, $planKey, $back){
    if ($back !== '' && strpos($back, '/interactive/') === 0) $_SESSION['mp_back'] = $back;
    $o = mp_order_create($pdo, $m, $planKey, 'checkout');
    if (!$o) { ac_flash('error', 'That plan is not available right now. Please pick another.'); ac_go('/account/plan/'); }
    if (function_exists('ix_event')) ix_event($pdo, 'plan_selected', 'membership', ['detail' => $planKey . ':checkout', 'path' => '/account/checkout/']);
    ac_go('/account/plan/' . rawurlencode($o['code']) . '/');
}
function ac_checkout(PDO $pdo){
    $plans = ac_checkout_plans($pdo);
    $pick = preg_replace('/[^a-z0-9_-]/', '', (string)($_POST['plan'] ?? $_GET['plan'] ?? $_GET['buy'] ?? ''));
    if (!isset($plans[$pick])) { $keys = array_keys($plans); $pick = in_array('bf12', $keys, true) ? 'bf12' : ($keys[0] ?? ''); }
    $back = ac_safe_next($_POST['back'] ?? $_GET['back'] ?? ''); if ($back === '/account/') $back = '';
    $m = ac_current($pdo);
    if ($m && isset($_GET['go']) && $pick !== '') ac_checkout_go($pdo, $m, $pick, $back);
    $err = ''; $vals = ['name' => '', 'email' => ''];
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!ac_csrf_ok()) $err = 'Your session expired. Please try again.';
        elseif (!empty($_POST['website'])) $err = 'Please try again.';
        elseif ($pick === '') $err = 'Please pick a plan.';
        elseif ($m) ac_checkout_go($pdo, $m, $pick, $back);
        else {
            $name = ac_clean_name($_POST['name'] ?? ''); $email = strtolower(trim((string)($_POST['email'] ?? ''))); $vals = ['name' => $name, 'email' => $email];
            if (ac_set($pdo, 'ac_signup_open') !== '1') $err = 'New sign-ups are paused for a short while. Please try again later.';
            elseif (!ac_rate('checkout', 6, 3600)) $err = 'Too many attempts from this connection. Please try again later.';
            elseif (mb_strlen($name) < 2) $err = 'Please enter your name.';
            elseif (!ac_valid_email($email)) $err = 'Please enter a valid email address. Your receipt and access link go there.';
            elseif (ac_member_by_email($pdo, $email)) $err = 'You already have an H View account with this email. Please sign in to continue. Your plan choice is kept.';
            else {
                $id = ac_create_member($pdo, $email, $name, null);
                ac_login($pdo, $id, true);
                try { /* a link to set a password later; the order page works without one */
                    $t = ac_token_make($pdo, $id, 'reset', 60 * 24 * 7);
                    $u = rtrim(setting_value($pdo, 'site_url', 'https://hview.in'), '/') . '/account/reset/?t=' . $t;
                    ac_mail($pdo, $email, 'Your H View account is ready', '<p>Hi ' . e($name) . ',</p><p>Welcome to H View. Your account was created while you chose a plan, so you can finish paying and use Premium right away.</p><p>To sign in on another device later, set your password here (link valid for 7 days):</p><p><a href="' . e($u) . '">' . e($u) . '</a></p><p>Team H View</p>');
                } catch (Throwable $e) { error_log('checkout mail: ' . $e->getMessage()); }
                ac_checkout_go($pdo, ac_current($pdo) ?: ['id' => $id, 'name' => $name, 'email' => $email], $pick, $back);
            }
        }
    }
    $p = $plans[$pick] ?? null; $gid = trim(ac_set($pdo, 'ac_google_client_id'));
    $self = '/account/checkout/?plan=' . rawurlencode($pick) . ($back !== '' ? '&back=' . rawurlencode($back) : '');
    $months = function ($pl) { $d = (int)$pl['days']; return $d >= 60 ? (int)round($d / 30.4) . ' months' : ($d >= 28 ? '1 month' : $d . ' days'); };
    $ben = $p ? (json_decode((string)($p['benefits'] ?? '[]'), true) ?: []) : [];
    $bf = function_exists('mp_bf_on') && mp_bf_on($pdo);
    ac_head($pdo, 'Checkout · H View Premium', 'Get H View Premium: every premium wish, invitation and tool.'); ?>
<div class="acx acx-auth acx-co">
  <section class="acx-auth-art">
    <p class="acx-kicker"><?=$bf ? 'Black Friday sale' : 'H View Premium'?></p>
    <h2>Every premium wish, <span class="acx-accent">no limits.</span></h2>
    <div class="co-plans" role="radiogroup" aria-label="Choose your plan">
      <?php foreach ($plans as $k => $pl): ?>
      <a class="co-plan<?=$k === $pick ? ' is-on' : ''?>" role="radio" aria-checked="<?=$k === $pick ? 'true' : 'false'?>" href="/account/checkout/?plan=<?=e($k)?><?=$back !== '' ? '&amp;back=' . e(rawurlencode($back)) : ''?>">
        <?php if ($k === 'bf12'): ?><em>Best value</em><?php elseif ($k === 'bf6'): ?><em>Popular</em><?php endif ?>
        <b>₹<?=number_format((int)$pl['price'])?></b><span><?=e($months($pl))?></span><?php if ((int)$pl['days'] >= 60): ?><small>₹<?=(int)round($pl['price'] / ((int)$pl['days'] / 30.4))?>/month</small><?php endif ?></a>
      <?php endforeach ?>
    </div>
    <?php if ($ben): ?><ul class="acx-ticks"><?php foreach (array_slice($ben, 0, 6) as $b): ?><li><?=ac_icon('spark')?><span><?=e($b)?></span></li><?php endforeach ?></ul><?php endif ?>
    <p class="acx-fine"><?=ac_icon('shield', 16)?> Pay once by UPI. Premium starts right away. Nothing renews automatically.</p>
  </section>
  <section class="acx-auth-card">
    <?php if ($p): ?><p class="co-sum"><span><?=e($p['name'])?> of Premium</span><b>₹<?=number_format((int)$p['price'])?></b></p><?php endif ?>
    <?php if ($m): ?>
      <h1>Ready to pay</h1><p class="acx-sub">Signed in as <b><?=e($m['email'])?></b>.</p>
      <form method="post" class="acx-form"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="plan" value="<?=e($pick)?>"><input type="hidden" name="back" value="<?=e($back)?>">
        <button class="acx-btn acx-btn-primary acx-btn-block" type="submit">Continue to UPI payment →</button></form>
    <?php else: ?>
      <h1>Almost yours</h1><p class="acx-sub">Just your name and email: we keep your Premium there and send your receipt. Already a member? <a href="/account/login/?next=<?=e(rawurlencode($self . '&go=1'))?>">Sign in</a></p>
      <?=ac_flashes()?><?php if ($err): ?><div class="acx-flash acx-flash-error" role="alert"><?=e($err)?><?php if (strpos($err, 'already have') !== false): ?> <a href="/account/login/?next=<?=e(rawurlencode($self . '&go=1'))?>">Sign in →</a><?php endif ?></div><?php endif ?>
      <?php if ($gid !== ''): ?><div class="acx-google" data-ac-google="<?=e($gid)?>" data-next="<?=e($self . '&go=1')?>"><noscript>Google sign-in needs JavaScript.</noscript></div><div class="acx-or"><span>or with email</span></div><?php endif ?>
      <form method="post" class="acx-form" novalidate>
        <input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="plan" value="<?=e($pick)?>"><input type="hidden" name="back" value="<?=e($back)?>">
        <div class="acx-hp" aria-hidden="true"><label>Website <input name="website" tabindex="-1" autocomplete="off"></label></div>
        <label class="acx-field"><span>Your name</span><input name="name" value="<?=e($vals['name'])?>" autocomplete="name" required maxlength="80"></label>
        <label class="acx-field"><span>Email</span><input type="email" name="email" value="<?=e($vals['email'])?>" autocomplete="email" required inputmode="email"></label>
        <button class="acx-btn acx-btn-primary acx-btn-block" type="submit">Continue to UPI payment →</button>
        <small class="acx-muted co-terms">By continuing you agree to the <a href="/terms-and-conditions/" target="_blank">terms</a> and <a href="/privacy-policy/" target="_blank">privacy policy</a>. We email you a link to set a password later.</small>
      </form>
    <?php endif ?>
    <ol class="co-steps"><li class="is-on">Your details</li><li>Pay by UPI</li><li>Premium unlocked</li></ol>
  </section>
</div>
<style>
.co-plans{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin:14px 0 18px}.co-plan{position:relative;display:flex;flex-direction:column;gap:2px;padding:14px 14px 12px;border:1.5px solid var(--line,#e4e7ec);border-radius:14px;background:#fff;color:inherit;text-decoration:none}
.co-plan b{font-size:1.35rem}.co-plan span{font-weight:600}.co-plan small{color:var(--muted,#667085)}.co-plan.is-on{border-color:#6553D9;box-shadow:0 0 0 3px rgba(101,83,217,.15);background:linear-gradient(135deg,#1E4CFF08,#D81B760a)}
.co-plan em{position:absolute;top:-9px;right:10px;font-style:normal;font-size:.72rem;font-weight:700;color:#fff;background:var(--grad,linear-gradient(90deg,#1E4CFF,#6553D9,#D81B76));border-radius:999px;padding:2px 9px}
.co-sum{display:flex;justify-content:space-between;align-items:center;margin:0 0 12px;padding:12px 14px;border-radius:12px;background:#f6f7fb;font-weight:600}.co-sum b{font-size:1.25rem}
.co-terms{display:block;margin-top:10px;line-height:1.5}.co-steps{display:flex;gap:6px;list-style:none;padding:0;margin:18px 0 0;font-size:.8rem;color:var(--muted,#667085)}
.co-steps li{flex:1;text-align:center;padding-top:8px;border-top:3px solid var(--line,#e4e7ec)}.co-steps li.is-on{border-color:#6553D9;color:var(--ink,#101828);font-weight:600}
@media(max-width:760px){.acx-co{display:flex;flex-direction:column-reverse}.acx-co .acx-auth-art h2{display:none}}
</style>
<script>window.HVM_CSRF=<?=json_encode(csrf())?>;</script>
<?php if ($gid !== '' && !$m): ?><script src="https://accounts.google.com/gsi/client" async defer></script><?php endif ?>
<?php ac_foot($pdo);
}
