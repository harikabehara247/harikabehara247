<?php
/* Black Friday tracker (r79, 25 Nov 2026). Opens at /admin/?m=dashboard&go=bf-tracker
 * One page for the whole sale: who saw the offer, scratched it, picked a plan, started checkout, paid, and became a subscriber.
 * Sources: hv_cta_clicks (placements bf_card / bf_strip, filled by assets/cta/hv-bf.js), hv_member_upgrades (plans bf*),
 * hv_ref_earnings (referral sales), hv_pageviews (visitors), hv_members (new accounts). Nothing here changes data. */
adm_require('bf-tracker');
$tz = new DateTimeZone('Asia/Kolkata');
$start = (string)setting_value($pdo, 'bf_start', '2026-11-25');
$until = (string)setting_value($pdo, 'bf_until', '2026-11-30 23:59:59');
$endDay = substr($until, 0, 10); $today = (new DateTime('now', $tz))->format('Y-m-d');
$live = $until >= (new DateTime('now', $tz))->format('Y-m-d H:i:s');
$days = []; for ($d = new DateTime($start, $tz); $d->format('Y-m-d') <= min($endDay, $today); $d->modify('+1 day')) $days[] = $d->format('Y-m-d');
if (!$days) $days = [$today];
$q = function ($sql, $args = []) use ($pdo) { try { $s = $pdo->prepare($sql); $s->execute($args); return $s->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable $e) { return []; } };
$one = function ($sql, $args = []) use ($q) { $r = $q($sql, $args); return $r ? (float)array_values($r[0])[0] : 0; };

/* ---- clicks from the strip and the scratch card */
$ev = []; $evDay = [];
foreach ($q("SELECT day, placement, action, SUM(n) n FROM hv_cta_clicks WHERE placement IN ('bf_card','bf_strip') AND day >= ? GROUP BY day, placement, action", [$start]) as $r) {
    $k = $r['placement'] . ':' . $r['action']; $ev[$k] = ($ev[$k] ?? 0) + (int)$r['n']; $evDay[$r['day']][$k] = ($evDay[$r['day']][$k] ?? 0) + (int)$r['n'];
}
$sum = function ($arr, $pred) { $t = 0; foreach ($arr as $k => $v) if ($pred($k)) $t += $v; return $t; };
$isSeen = function ($k) { return $k === 'bf_card:view' || $k === 'bf_card:open'; };
$isScr = function ($k) { return strpos($k, 'bf_card:reveal_') === 0; };
$isPick = function ($k) { return strpos($k, 'bf_card:click_') === 0; };
$seen = $sum($ev, $isSeen); $scr = $sum($ev, $isScr); $picked = $sum($ev, $isPick);
$stripClicks = (int)($ev['bf_strip:click'] ?? 0);
$closedUnscratched = (int)($ev['bf_card:close_unscratched'] ?? 0) + (int)($ev['bf_card:later_unscratched'] ?? 0);
$closedAfter = (int)($ev['bf_card:close'] ?? 0) + (int)($ev['bf_card:later'] ?? 0);
$planClicks = []; foreach (['m3' => 'bf3', 'm6' => 'bf6', 'm8' => 'bf8', 'm12' => 'bf12'] as $a => $k) $planClicks[$k] = (int)($ev['bf_card:click_' . $a] ?? 0);

/* ---- orders for the sale plans */
$orders = $q("SELECT u.*, m.name, m.email FROM hv_member_upgrades u LEFT JOIN hv_members m ON m.id = u.member_id WHERE u.plan LIKE 'bf%' ORDER BY u.id DESC");
$dead = ['rejected', 'cancelled', 'refunded', 'expired'];
$st = ['started' => 0, 'paying' => 0, 'confirmed' => 0, 'lost' => 0, 'revenue' => 0, 'pipeline' => 0]; $byPlan = []; $ordDay = []; $subs = [];
foreach ($orders as $o) {
    $p = $o['plan']; $byPlan[$p] = $byPlan[$p] ?? ['orders' => 0, 'confirmed' => 0, 'revenue' => 0]; $byPlan[$p]['orders']++;
    $d = substr($o['created_at'], 0, 10); $ordDay[$d]['started'] = ($ordDay[$d]['started'] ?? 0) + 1; $st['started']++;
    $amt = (int)($o['paid_amount'] ?: $o['amount']);
    if (in_array($o['status'], $dead, true)) { $st['lost']++; continue; }
    if (!empty($o['verified_at'])) {
        $st['confirmed']++; $st['revenue'] += $amt; $byPlan[$p]['confirmed']++; $byPlan[$p]['revenue'] += $amt; $subs[(int)$o['member_id']] = 1;
        $cd = substr($o['verified_at'], 0, 10); $ordDay[$cd]['confirmed'] = ($ordDay[$cd]['confirmed'] ?? 0) + 1; $ordDay[$cd]['revenue'] = ($ordDay[$cd]['revenue'] ?? 0) + $amt;
    } elseif (!empty($o['upi_ref'])) { $st['paying']++; $st['pipeline'] += $amt; }
}
$awaiting = $st['started'] - $st['paying'] - $st['confirmed'] - $st['lost'];
/* first-time subscribers: no confirmed paid order before this sale */
$newSubs = 0;
foreach (array_keys($subs) as $mid) if (!$one("SELECT COUNT(*) FROM hv_member_upgrades WHERE member_id=? AND amount>0 AND verified_at IS NOT NULL AND plan NOT LIKE 'bf%' AND created_at < ?", [$mid, $start])) $newSubs++;

/* ---- context: visitors, new accounts, referral sales */
$visitors = (int)$one("SELECT COUNT(DISTINCT COALESCE(NULLIF(cid,''), visitor)) FROM hv_pageviews WHERE kind='reader' AND created_at >= ?", [$start]);
if (!$visitors) $visitors = (int)$one("SELECT COUNT(DISTINCT visitor) FROM hv_pageviews WHERE kind='reader' AND created_at >= ?", [$start]);
$visDay = []; foreach ($q("SELECT DATE(created_at) d, COUNT(DISTINCT visitor) n FROM hv_pageviews WHERE kind='reader' AND created_at >= ? GROUP BY DATE(created_at)", [$start]) as $r) $visDay[$r['d']] = (int)$r['n'];
$signups = (int)$one('SELECT COUNT(*) FROM hv_members WHERE created_at >= ?', [$start]);
$refSales = $q("SELECT COUNT(*) n, COALESCE(SUM(e.amount),0) amt, COALESCE(SUM(e.commission),0) com FROM hv_ref_earnings e JOIN hv_member_upgrades u ON u.id=e.order_id WHERE u.plan LIKE 'bf%' AND e.status<>'void'");
$refSales = $refSales[0] ?? ['n' => 0, 'amt' => 0, 'com' => 0];

$pct = function ($a, $b) { return $b > 0 ? round($a / $b * 100, 1) . '%' : '—'; };
$names = ['bf3' => '3 months · ₹199', 'bf6' => '6 months · ₹299', 'bf8' => '8 months · ₹399', 'bf12' => '12 months · ₹499'];
$funnel = [
    ['Saw the offer card', $seen, 'Card shown automatically or opened from the strip'],
    ['Scratched or tapped to reveal', $scr, 'Revealed the ₹499 / from ₹199 offer'],
    ['Clicked a plan', $picked, 'Pressed "Get … months" in the card'],
    ['Started checkout', $st['started'], 'Signed in and created a sale order'],
    ['Paid and sent the UTR', $st['paying'] + $st['confirmed'], 'Willing buyers: payment reported'],
    ['Confirmed subscribers', $st['confirmed'], 'You verified the payment'],
];
$max = max(1, $funnel[0][1], $st['started']);

adm_head($pdo, 'bf-tracker', 'Black Friday tracker');
adm_page_head('Black Friday tracker', ($live ? 'Live now · ' : 'Ended · ') . 'From ' . date('j M', strtotime($start)) . ' to ' . date('j M, g:i A', strtotime($until)) . ' IST. Every step from seeing the scratch card to a confirmed subscriber. Updates on every refresh.', []);
?>
<div class="adm-kpis">
  <?=adm_kpi('Confirmed subscribers', number_format($st['confirmed']), $newSubs . ' first-time · ' . $pct($st['confirmed'], $visitors) . ' of visitors', 'check', null, 'green')?>
  <?=adm_kpi('Revenue confirmed', '₹' . number_format($st['revenue']), '₹' . number_format($st['pipeline']) . ' more waiting for your check', 'chart', null, 'blue')?>
  <?=adm_kpi('Willing to buy', number_format($st['paying'] + max(0, $awaiting)), $st['paying'] . ' paid, to verify · ' . max(0, $awaiting) . ' started, not paid', 'clock', null, 'pink')?>
  <?=adm_kpi('Scratched the card', number_format($scr), $pct($scr, $seen) . ' of ' . number_format($seen) . ' who saw it', 'eye', null, 'violet')?>
</div>

<div class="bft-grid">
<section class="adm-card"><h2>Sale funnel</h2><p class="bft-sub">Each bar is a share of the people who saw the card. The % on the right is from the step above.</p>
  <ol class="bft-funnel"><?php foreach ($funnel as $i => $f): $w = max(2, round($f[1] / $max * 100)); ?>
    <li><div class="bft-fl"><b><?=e($f[0])?></b><small><?=e($f[2])?></small></div>
      <div class="bft-bar"><i style="width:<?=$w?>%"></i><span><?=number_format($f[1])?></span></div>
      <em><?=$i ? $pct($f[1], $funnel[$i - 1][1]) : ''?></em></li><?php endforeach ?></ol>
  <p class="bft-note">Also: <b><?=number_format($stripClicks)?></b> taps on "Reveal my offer" in the top strip · <b><?=number_format($closedUnscratched)?></b> closed without scratching · <b><?=number_format($closedAfter)?></b> closed after revealing · <b><?=number_format($signups)?></b> new accounts since <?=date('j M', strtotime($start))?> · <b><?=number_format($visitors)?></b> visitors.</p>
</section>

<section class="adm-card"><h2>Which plan</h2><p class="bft-sub">Clicks in the card, orders started and payments confirmed.</p>
  <table class="adm-table bft-plans"><thead><tr><th>Plan</th><th>Clicked</th><th>Orders</th><th>Paid</th><th>Revenue</th></tr></thead><tbody>
  <?php foreach ($names as $k => $label): $b = $byPlan[$k] ?? ['orders' => 0, 'confirmed' => 0, 'revenue' => 0]; ?>
    <tr><td><b><?=e($label)?></b></td><td><?=number_format($planClicks[$k])?></td><td><?=number_format($b['orders'])?></td><td><?=number_format($b['confirmed'])?></td><td>₹<?=number_format($b['revenue'])?></td></tr>
  <?php endforeach ?></tbody></table>
  <p class="bft-note">Referral sales in this offer: <b><?=(int)$refSales['n']?></b> (₹<?=number_format((int)$refSales['amt'])?>), commission <?=e('₹' . number_format(((int)$refSales['com']) / 100, 2))?>.</p>
</section>
</div>

<section class="adm-card adm-card-flush"><div class="bft-h"><h2>Day by day</h2></div>
  <div class="adm-table-wrap"><table class="adm-table"><thead><tr><th>Day</th><th>Visitors</th><th>Saw card</th><th>Scratched</th><th>Clicked plan</th><th>Orders started</th><th>Confirmed</th><th>Revenue</th></tr></thead><tbody>
  <?php foreach (array_reverse($days) as $d): $e = $evDay[$d] ?? []; $o = $ordDay[$d] ?? []; ?>
    <tr><td><b><?=date('D j M', strtotime($d))?></b><?=$d === $today ? ' <small>today</small>' : ''?></td><td><?=number_format($visDay[$d] ?? 0)?></td><td><?=number_format($sum($e, $isSeen))?></td><td><?=number_format($sum($e, $isScr))?></td>
      <td><?=number_format($sum($e, $isPick))?></td><td><?=number_format($o['started'] ?? 0)?></td><td><?=number_format($o['confirmed'] ?? 0)?></td><td>₹<?=number_format($o['revenue'] ?? 0)?></td></tr>
  <?php endforeach ?></tbody></table></div>
</section>

<section class="adm-card adm-card-flush"><div class="bft-h"><h2>Sale orders</h2><small>Newest first. Confirm payments under Premium Orders as usual. Buyers who paid but are not confirmed are waiting on you.</small></div>
  <?php if (!$orders): ?><p class="bft-empty">No sale orders yet.</p><?php else: ?>
  <div class="adm-table-wrap"><table class="adm-table"><thead><tr><th>When</th><th>Member</th><th>Plan</th><th>Amount</th><th>UTR</th><th>Status</th><th>Referred</th></tr></thead><tbody>
  <?php foreach (array_slice($orders, 0, 100) as $o): $s = in_array($o['status'], $dead, true) ? ucfirst($o['status']) : (!empty($o['verified_at']) ? 'Confirmed' : (!empty($o['upi_ref']) ? 'Paid · verify' : 'Not paid yet')); ?>
    <tr><td><?=e(adm_date($o['created_at'], 'j M, g:i A'))?></td><td><b><?=e($o['name'] ?? '—')?></b><br><small><?=e($o['email'] ?? '')?></small></td><td><?=e($names[$o['plan']] ?? $o['plan'])?></td>
      <td>₹<?=number_format((int)($o['paid_amount'] ?: $o['amount']))?></td><td><?=$o['upi_ref'] ? '<code>' . e($o['upi_ref']) . '</code>' : '—'?></td>
      <td><span class="bft-pill is-<?=strtolower(strtok($s, ' '))?>"><?=e($s)?></span></td><td><?=!empty($o['ref_by']) ? 'Yes' : ''?></td></tr>
  <?php endforeach ?></tbody></table></div><?php endif ?>
</section>
<style>
.bft-grid{display:grid;grid-template-columns:1.35fr 1fr;gap:18px;margin-bottom:18px}.bft-sub{margin:-4px 0 14px;color:var(--muted);font-size:.9rem}
.bft-funnel{list-style:none;margin:0;padding:0;display:grid;gap:10px}.bft-funnel li{display:grid;grid-template-columns:200px 1fr 56px;gap:12px;align-items:center}
.bft-fl b{display:block;font-size:.92rem}.bft-fl small{color:var(--muted);font-size:.78rem}
.bft-bar{position:relative;height:30px;background:#f2f4f9;border-radius:9px;overflow:hidden}.bft-bar i{position:absolute;inset:0 auto 0 0;background:var(--grad,linear-gradient(90deg,#1E4CFF,#6553D9,#D81B76));border-radius:9px;opacity:.88}
.bft-bar span{position:relative;display:block;line-height:30px;padding-left:10px;font-weight:700;color:#fff;text-shadow:0 1px 2px rgba(0,0,0,.25)}
.bft-funnel em{font-style:normal;color:var(--muted);font-size:.85rem;text-align:right}.bft-note{margin:16px 0 0;color:var(--muted);font-size:.88rem;line-height:1.6}
.bft-plans td,.bft-plans th{white-space:nowrap}.bft-h{padding:18px 20px 6px}.bft-h h2{margin:0 0 4px;font-size:1.05rem}.bft-h small{color:var(--muted)}.bft-empty{padding:6px 20px 20px;color:var(--muted)}
.bft-pill{display:inline-block;padding:3px 9px;border-radius:999px;font-size:.78rem;font-weight:600;background:#f2f4f7;color:#475467}.bft-pill.is-confirmed{background:#e7f8ef;color:#067647}.bft-pill.is-paid{background:#fff4e5;color:#b54708}
@media(max-width:1000px){.bft-grid{grid-template-columns:1fr}.bft-funnel li{grid-template-columns:1fr 60px}.bft-fl{grid-column:1/-1}}
</style>
<?php adm_foot();
