<?php
$f='app.php'; $s=file_get_contents($f);
$p=json_decode(file_get_contents(__DIR__.'/apppatch.json'),true);
foreach($p as $x){ if(substr_count($s,$x[0])!==1){ echo 'ANCHOR FAIL: '.substr($x[0],0,40)."\n"; exit(1);} }
foreach($p as $x) $s=str_replace($x[0],$x[1],$s);
file_put_contents($f,$s); echo "app ok\n";
