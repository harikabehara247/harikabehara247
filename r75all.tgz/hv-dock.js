/* H View floating icons, site-wide (r75b, 24 Nov 2026).
 * One tidy column of round navy icons on every page, so they never overlap each other or the language picker:
 * WhatsApp (bottom), language, call, back to top. On greeting-maker pages ix.js builds the same column with
 * the wish helper at the bottom; this file then does nothing. */
(function () {
  'use strict';
  var d = document, html = d.documentElement;
  if (html.classList.contains('ix-has-helper')) return;
  var css = ':root{--hvdb:18px}'
    + '.hv-dock{position:fixed;z-index:9991;right:max(14px,env(safe-area-inset-right));bottom:calc(var(--hvdb) + env(safe-area-inset-bottom));display:flex;flex-direction:column-reverse;gap:10px}'
    + 'html body .hv-dock>.hvw-fab,html body .hv-dock>.hvl,html body .hv-dock>.hvc-callfab,html body .hv-dock>.hv-totop,html.hv-stuck body .hv-dock>*,.hv-dock>*{position:relative!important;inset:auto!important;right:auto!important;left:auto!important;bottom:auto!important;top:auto!important;margin:0!important;transform:none}'
    + '.hv-dock .hvw-fab,.hv-dock .hvc-callfab,.hv-dock .hvl>button,.hv-dock .hv-totop{width:48px!important;height:48px!important;min-height:0!important;padding:0!important;display:grid!important;place-items:center;border-radius:50%!important;background:#18213d!important;border:2px solid rgba(255,255,255,.9)!important;color:#fff!important;box-shadow:0 8px 20px -6px rgba(12,18,40,.55)!important;font-size:0!important;line-height:0;grid-template:1fr/1fr!important;gap:0!important}'
    + '.hv-dock .hvl>button>*{grid-area:1/1}'
    + '.hv-dock .hvw-fab{color:#3ee07f!important}'
    + '.hv-dock .hvw-fab span{font-size:13px!important;line-height:1!important}'
    + '.hv-dock .hvc-ring{display:none!important}'
    + '.hv-dock .hvw-fab::before,.hv-dock .hvw-fab::after,.hv-dock .hvc-callfab::before,.hv-dock .hvc-callfab::after{display:none!important}'
    + '.hv-dock .hvc-callfab svg{width:20px;height:20px}.hv-dock .hvw-fab svg{width:24px;height:24px}.hv-dock .hv-totop svg{width:18px;height:18px}'
    + '.hv-dock .hvl{position:relative!important}'
    + '.hv-dock .hvl ul{position:absolute!important;right:calc(100% + 10px)!important;bottom:0!important;left:auto!important;top:auto!important;margin:0!important;min-width:150px}'
    + '.hv-dock .hv-totop:not(.is-on){visibility:hidden;opacity:0}'
    + '.hv-dock .hvw-fab:hover,.hv-dock .hvc-callfab:hover,.hv-dock .hvl>button:hover,.hv-dock .hv-totop:hover{background:#2a3563!important}'
    + '.hv-dock-on .hvw-card{right:calc(max(14px,env(safe-area-inset-right)) + 60px)!important;bottom:calc(var(--hvdb) + env(safe-area-inset-bottom))!important}'
    + '@media (max-width:700px){.hv-dock{gap:8px}.hv-dock .hvw-fab,.hv-dock .hvc-callfab,.hv-dock .hvl>button,.hv-dock .hv-totop{width:42px!important;height:42px!important}.hv-dock-on .hvw-card{right:calc(max(14px,env(safe-area-inset-right)) + 52px)!important}}';
  var st = d.createElement('style'); st.id = 'hv-dock-css'; st.textContent = css; d.head.appendChild(st);
  var dock = null;
  var GLOBE = '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.6 3.8 5.6 3.8 9s-1.2 6.4-3.8 9c-2.6-2.6-3.8-5.6-3.8-9S9.4 5.6 12 3z"/></svg>';
  function q(s) { return d.querySelector(s); }
  function base() {
    var b = 18, nav = q('.mobile-app-nav');
    if (nav && getComputedStyle(nav).display !== 'none') { var r = nav.getBoundingClientRect(); if (r.height) b = Math.max(18, Math.round(innerHeight - r.top) + 12); }
    html.style.setProperty('--hvdb', b + 'px');
  }
  function adopt() {
    if (html.classList.contains('ix-has-helper')) { if (dock) dock.remove(); return; }
    var want = [q('.hvw-fab'), q('.hvl'), q('.hvc-callfab'), q('.hv-totop')].filter(Boolean);
    if (!want.length) return;
    if (!dock) { dock = d.createElement('div'); dock.className = 'hv-dock'; d.body.appendChild(dock); html.classList.add('hv-dock-on'); }
    var have = [].slice.call(dock.children);
    if (want.some(function (el, i) { return have[i] !== el; })) want.forEach(function (el) { dock.appendChild(el); });
    var lb = q('.hvl > button');
    if (lb && !lb.getAttribute('data-hv-globe')) {
      [].slice.call(lb.childNodes).forEach(function (n) { if (n.nodeType === 3 && n.textContent.trim()) { lb.setAttribute('aria-label', 'Language: ' + n.textContent.trim()); n.textContent = ''; } });
      var sp = lb.querySelector('span'); if (sp) sp.innerHTML = GLOBE; lb.title = 'Change language'; lb.setAttribute('data-hv-globe', '1');
    }
    var cf = q('.hv-dock .hvc-callfab'), tip = q('#hvc-calltip');
    if (cf && tip) { var r = cf.getBoundingClientRect(); if (r.height) { tip.style.setProperty('bottom', Math.max(8, Math.round(innerHeight - r.bottom)) + 'px', 'important'); tip.style.setProperty('right', Math.round(innerWidth - r.left + 12) + 'px', 'important'); } }
    base();
  }
  function start() {
    adopt(); [300, 1200, 3000, 7000].forEach(function (ms) { setTimeout(adopt, ms); });
    addEventListener('resize', adopt);
    try { new MutationObserver(function (m) { if (m.some(function (x) { return x.addedNodes.length; })) adopt(); }).observe(d.body, { childList: true }); } catch (e) {}
  }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})();
