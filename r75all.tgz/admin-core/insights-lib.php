<?php
/* Visitor insights (r75, 24 Nov 2026): returning visitors, sessions, time per session and country.
 *  - The page tracker (hv_footer_codes in app.php) now sends an anonymous browser id (c, kept in localStorage),
 *    a session id (sn, new after 30 minutes without activity), the time zone, and a heartbeat every 15 s.
 *  - Country comes from the visitor's IP address, looked up in a local file built from the free DB-IP Lite
 *    country database (CC BY 4.0). No IP address is stored; nothing is sent to an outside service.
 *  - hv_an_clients keeps one row per browser id: first and last visit, sessions, views and seconds. */

function hv_an_migrate(PDO $pdo){
    if (setting_value($pdo, 'an_schema', '') === '2') return;
    foreach (['cid' => 'CHAR(12) NULL', 'sid' => 'CHAR(12) NULL', 'country' => 'CHAR(2) NULL'] as $c => $def) {
        try { if (!adm_has_column($pdo, 'hv_pageviews', $c)) $pdo->exec("ALTER TABLE hv_pageviews ADD COLUMN $c $def"); } catch (Throwable $e) { error_log('H View insights column ' . $c . ': ' . $e->getMessage()); }
    }
    try { $pdo->exec('ALTER TABLE hv_pageviews ADD INDEX hv_pv_cid (cid)'); } catch (Throwable $e) {}
    try { $pdo->exec('ALTER TABLE hv_pageviews ADD INDEX hv_pv_sid (sid)'); } catch (Throwable $e) {}
    $pdo->exec("CREATE TABLE IF NOT EXISTS hv_an_clients (cid CHAR(12) NOT NULL PRIMARY KEY, first_at DATETIME NOT NULL, last_at DATETIME NOT NULL,
        sessions INT UNSIGNED NOT NULL DEFAULT 1, views INT UNSIGNED NOT NULL DEFAULT 0, last_sid CHAR(12) NULL, country CHAR(2) NULL, device VARCHAR(10) NULL,
        INDEX(first_at), INDEX(last_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if (adm_has_column($pdo, 'hv_pageviews', 'cid') && adm_has_column($pdo, 'hv_pageviews', 'country')) site_settings_save($pdo, ['an_schema' => '2']);
}

/* Two-letter country code for an IP address, or '' when unknown. Binary search over fixed-size records:
 * v4.bin = [start(4) end(4) cc(2)], v6.bin = [start(16) end(16) cc(2)], sorted by start. */
function hv_an_country($ip){
    $bin = @inet_pton((string)$ip); if ($bin === false || $bin === null) return '';
    if (strlen($bin) === 16 && substr($bin, 0, 12) === "\0\0\0\0\0\0\0\0\0\0\xff\xff") $bin = substr($bin, 12);
    $w = strlen($bin); $f = __DIR__ . '/data/geo/' . ($w === 4 ? 'v4' : 'v6') . '.bin'; $rec = $w * 2 + 2;
    $h = @fopen($f, 'rb'); if (!$h) return '';
    $n = (int)(filesize($f) / $rec); $lo = 0; $hi = $n - 1; $cc = '';
    while ($lo <= $hi) {
        $mid = ($lo + $hi) >> 1; fseek($h, $mid * $rec); $r = fread($h, $rec);
        $s = substr($r, 0, $w); $e = substr($r, $w, $w);
        if (strcmp($bin, $s) < 0) $hi = $mid - 1;
        elseif (strcmp($bin, $e) > 0) $lo = $mid + 1;
        else { $cc = substr($r, $w * 2, 2); break; }
    }
    fclose($h);
    return preg_match('/^[A-Z]{2}$/', $cc) && $cc !== 'ZZ' ? $cc : '';
}
/* When the IP is unknown, a few time zones still tell the country */
function hv_an_tz_country($tz){
    $m = ['Asia/Kolkata' => 'IN', 'Asia/Calcutta' => 'IN', 'Asia/Dubai' => 'AE', 'Asia/Riyadh' => 'SA', 'Asia/Qatar' => 'QA', 'Asia/Kuwait' => 'KW', 'Asia/Muscat' => 'OM', 'Asia/Bahrain' => 'BH',
        'Asia/Singapore' => 'SG', 'Asia/Kathmandu' => 'NP', 'Asia/Dhaka' => 'BD', 'Asia/Karachi' => 'PK', 'Asia/Colombo' => 'LK', 'Europe/London' => 'GB', 'Australia/Sydney' => 'AU', 'Australia/Melbourne' => 'AU', 'Pacific/Auckland' => 'NZ', 'Asia/Tokyo' => 'JP', 'Europe/Berlin' => 'DE', 'Europe/Paris' => 'FR', 'America/Toronto' => 'CA'];
    return $m[(string)$tz] ?? '';
}
function hv_an_id($v){ return preg_match('/^[a-z0-9]{8,12}$/', (string)$v) ? (string)$v : null; }

/* Called by the tracker for every new page view of a real reader */
function hv_an_record(PDO $pdo, $pvId, array $raw, $device){
    hv_an_migrate($pdo);
    $cid = hv_an_id($raw['c'] ?? ''); $sid = hv_an_id($raw['sn'] ?? '');
    $cc = hv_an_country($_SERVER['REMOTE_ADDR'] ?? ''); if ($cc === '') $cc = hv_an_tz_country($raw['tz'] ?? '');
    try { adm_q($pdo, 'UPDATE hv_pageviews SET cid = ?, sid = ?, country = ? WHERE id = ?', [$cid, $sid, $cc !== '' ? $cc : null, $pvId]); } catch (Throwable $e) { return; }
    if (!$cid) return;
    $now = date('Y-m-d H:i:s');
    try {
        adm_q($pdo, 'INSERT INTO hv_an_clients (cid, first_at, last_at, sessions, views, last_sid, country, device) VALUES (?,?,?,1,1,?,?,?)
            ON DUPLICATE KEY UPDATE sessions = sessions + IF(last_sid <=> VALUES(last_sid), 0, 1), views = views + 1, last_at = VALUES(last_at), last_sid = VALUES(last_sid),
            country = COALESCE(VALUES(country), country), device = VALUES(device)', [$cid, $now, $now, $sid, $cc !== '' ? $cc : null, $device]);
    } catch (Throwable $e) { error_log('H View insights client: ' . $e->getMessage()); }
}

/* Country names for the report (the most common ones; others show their code) */
function hv_an_country_name($cc){
    static $n = ['IN' => 'India', 'US' => 'United States', 'AE' => 'United Arab Emirates', 'GB' => 'United Kingdom', 'CA' => 'Canada', 'AU' => 'Australia', 'SA' => 'Saudi Arabia', 'SG' => 'Singapore',
        'QA' => 'Qatar', 'KW' => 'Kuwait', 'OM' => 'Oman', 'BH' => 'Bahrain', 'NP' => 'Nepal', 'BD' => 'Bangladesh', 'PK' => 'Pakistan', 'LK' => 'Sri Lanka', 'DE' => 'Germany', 'FR' => 'France',
        'NL' => 'Netherlands', 'IE' => 'Ireland', 'NZ' => 'New Zealand', 'MY' => 'Malaysia', 'ID' => 'Indonesia', 'PH' => 'Philippines', 'JP' => 'Japan', 'CN' => 'China', 'HK' => 'Hong Kong',
        'ZA' => 'South Africa', 'NG' => 'Nigeria', 'KE' => 'Kenya', 'IT' => 'Italy', 'ES' => 'Spain', 'SE' => 'Sweden', 'CH' => 'Switzerland', 'BR' => 'Brazil', 'MX' => 'Mexico', 'RU' => 'Russia', 'TH' => 'Thailand', 'VN' => 'Vietnam', 'KR' => 'South Korea', 'FI' => 'Finland', 'PL' => 'Poland'];
    return $n[$cc] ?? $cc;
}
function hv_an_flag($cc){
    if (!preg_match('/^[A-Z]{2}$/', (string)$cc)) return '🌐';
    return mb_chr(0x1F1E6 + ord($cc[0]) - 65) . mb_chr(0x1F1E6 + ord($cc[1]) - 65);
}
