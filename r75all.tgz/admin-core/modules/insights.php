<?php
/* Visitor insights (r75, 24 Nov 2026): a plain-language replacement for the Google Analytics reports we use most.
 * Real readers only (kind = 'reader'). Opens at /admin/?m=dashboard&go=insights
 *  - visitors, new vs returning, sessions, time per session, page views, engaged visits, with change vs the previous period
 *  - trend by day / week / month, how long sessions last, when people visit (hour of day)
 *  - countries, traffic sources, devices, top pages, and what visits turned into (greetings, payments)
 * Sessions and returning visitors are exact from 24 Nov 2026 (tracker update r75). Before that, a session is
 * approximated as one visitor-day and country is unknown. */
adm_require('insights');
require_once HV_CORE . '/insights-lib.php';
hv_an_migrate($pdo);

$tz = new DateTimeZone('Asia/Kolkata'); $today = new DateTime('today', $tz);
$ranges = ['today' => 'Today', 'yesterday' => 'Yesterday', '7d' => '7 days', '30d' => '30 days', '90d' => '90 days', 'month' => 'This month', 'lastmonth' => 'Last month', 'year' => 'This year'];
$r = (string)($_GET['r'] ?? '30d'); if (!isset($ranges[$r]) && $r !== 'custom') $r = '30d';
$f = clone $today; $t = clone $today;
switch ($r) {
    case 'today': break;
    case 'yesterday': $f->modify('-1 day'); $t->modify('-1 day'); break;
    case '7d': $f->modify('-6 days'); break;
    case '90d': $f->modify('-89 days'); break;
    case 'month': $f->modify('first day of this month'); break;
    case 'lastmonth': $f->modify('first day of last month'); $t = (clone $today)->modify('last day of last month'); break;
    case 'year': $f->setDate((int)$today->format('Y'), 1, 1); break;
    case 'custom':
        $a = DateTime::createFromFormat('Y-m-d', (string)($_GET['from'] ?? ''), $tz); $b = DateTime::createFromFormat('Y-m-d', (string)($_GET['to'] ?? ''), $tz);
        if ($a && $b) { $f = $a->setTime(0, 0); $t = $b->setTime(0, 0); if ($f > $t) [$f, $t] = [$t, $f]; } else { $r = '30d'; $f->modify('-29 days'); }
        break;
    default: $f->modify('-29 days');
}
$days = (int)$f->diff($t)->days + 1;
$g = (string)($_GET['g'] ?? ''); if (!in_array($g, ['day', 'week', 'month'], true)) $g = $days <= 31 ? 'day' : ($days <= 140 ? 'week' : 'month');
$from = $f->format('Y-m-d 00:00:00'); $to = $t->format('Y-m-d 23:59:59');
$pf = (clone $f)->modify('-' . $days . ' days')->format('Y-m-d 00:00:00'); $pt = (clone $f)->modify('-1 day')->format('Y-m-d 23:59:59');
$SK = "COALESCE(sid, CONCAT(visitor, DATE(created_at)))"; $VK = "COALESCE(cid, visitor)";
$W = "kind = 'reader' AND created_at BETWEEN ? AND ?";

$kpi = function ($a, $b) use ($pdo, $SK, $VK, $W) {
    $x = adm_q($pdo, "SELECT COUNT(*) v, COUNT(DISTINCT $VK) u, COUNT(DISTINCT $SK) s, COALESCE(SUM(seconds),0) sec, COALESCE(AVG(engaged),0) eng FROM hv_pageviews WHERE $W", [$a, $b])->fetch(PDO::FETCH_ASSOC);
    $x['avg'] = $x['s'] ? $x['sec'] / $x['s'] : 0; return $x;
};
$now = $kpi($from, $to); $prev = $kpi($pf, $pt);
$nr = adm_q($pdo, "SELECT SUM(c.first_at >= ?) n, SUM(c.first_at < ?) r FROM (SELECT DISTINCT cid FROM hv_pageviews WHERE $W AND cid IS NOT NULL) p JOIN hv_an_clients c ON c.cid = p.cid", [$from, $from, $from, $to])->fetch(PDO::FETCH_NUM);
$newV = (int)$nr[0]; $retV = (int)$nr[1];
$cameBack = (int)adm_val($pdo, "SELECT COUNT(*) FROM (SELECT cid FROM hv_pageviews WHERE $W AND cid IS NOT NULL AND sid IS NOT NULL GROUP BY cid HAVING COUNT(DISTINCT sid) > 1) x", [$from, $to]);
$live = adm_q($pdo, "SELECT COUNT(DISTINCT $VK) FROM hv_pageviews WHERE kind = 'reader' AND created_at >= ?", [date('Y-m-d H:i:s', time() - 300)])->fetchColumn();

/* trend */
$bk = ['day' => "DATE(created_at)", 'week' => "DATE(DATE_SUB(created_at, INTERVAL WEEKDAY(created_at) DAY))", 'month' => "DATE_FORMAT(created_at, '%Y-%m-01')"][$g];
$rows = adm_q($pdo, "SELECT $bk b, COUNT(DISTINCT $VK) u, COUNT(DISTINCT $SK) s, COUNT(*) v, COALESCE(SUM(seconds),0) sec FROM hv_pageviews WHERE $W GROUP BY b ORDER BY b", [$from, $to])->fetchAll(PDO::FETCH_ASSOC);
$byB = []; foreach ($rows as $x) $byB[$x['b']] = $x;
$labels = []; $sU = []; $sS = []; $sT = [];
$cur = clone $f; if ($g === 'week') $cur->modify('-' . ((int)$cur->format('N') - 1) . ' days'); if ($g === 'month') $cur->modify('first day of this month');
for ($i = 0; $i < 400 && $cur <= $t; $i++) {
    $k = $cur->format('Y-m-d'); $x = $byB[$k] ?? null;
    $labels[] = $g === 'month' ? $cur->format('M Y') : ($g === 'week' ? 'Wk of ' . $cur->format('j M') : $cur->format('j M'));
    $sU[] = (int)($x['u'] ?? 0); $sS[] = (int)($x['s'] ?? 0); $sT[] = $x && $x['s'] ? round($x['sec'] / $x['s'] / 60, 1) : 0;
    $cur->modify($g === 'day' ? '+1 day' : ($g === 'week' ? '+1 week' : '+1 month'));
}
/* session length */
$len = adm_q($pdo, "SELECT SUM(t < 10) a, SUM(t >= 10 AND t < 60) b, SUM(t >= 60 AND t < 180) c, SUM(t >= 180 AND t < 300) d, SUM(t >= 300 AND t < 600) e, SUM(t >= 600) f
    FROM (SELECT $SK k, SUM(seconds) t FROM hv_pageviews WHERE $W GROUP BY k) x", [$from, $to])->fetch(PDO::FETCH_NUM);
$lenL = ['Under 10 s', '10 s – 1 min', '1 – 3 min', '3 – 5 min', '5 – 10 min', 'Over 10 min'];
/* hour of day */
$hrs = array_fill(0, 24, 0); foreach (adm_q($pdo, "SELECT HOUR(created_at) h, COUNT(DISTINCT $SK) n FROM hv_pageviews WHERE $W GROUP BY h", [$from, $to]) as $x) $hrs[(int)$x['h']] = (int)$x['n'];
/* countries */
$ctry = adm_q($pdo, "SELECT COALESCE(country, '') cc, COUNT(DISTINCT $VK) u, COUNT(DISTINCT $SK) s, COALESCE(SUM(seconds),0) sec FROM hv_pageviews WHERE $W GROUP BY cc ORDER BY u DESC LIMIT 12", [$from, $to])->fetchAll(PDO::FETCH_ASSOC);
/* sources */
$chan = function ($h) {
    $h = strtolower(preg_replace('/^www\./', '', (string)$h));
    if ($h === '') return 'Direct or app';
    foreach (['Google' => '/(^|\.)google\.|googleusercontent|^android-app:\/\/com\.google/', 'ChatGPT' => '/chatgpt|openai/', 'WhatsApp' => '/whatsapp|^wa\.me|l\.wl\.co/', 'Facebook' => '/facebook|^fb\.|^m\.facebook|^l\.facebook/',
        'Instagram' => '/instagram/', 'Bing' => '/bing\./', 'Perplexity' => '/perplexity/', 'YouTube' => '/youtube|youtu\.be/', 'X (Twitter)' => '/^t\.co$|twitter|^x\.com/', 'LinkedIn' => '/linkedin|lnkd/',
        'Gemini' => '/gemini\.google|bard/', 'Copilot' => '/copilot/', 'DuckDuckGo' => '/duckduckgo/', 'Yahoo' => '/yahoo/'] as $n => $re) if (preg_match($re, $h)) return $n;
    return 'Other sites';
};
$src = [];
foreach (adm_q($pdo, "SELECT COALESCE(referrer,'') h, COUNT(DISTINCT $VK) u, COUNT(DISTINCT $SK) s, COALESCE(SUM(seconds),0) sec FROM hv_pageviews WHERE $W GROUP BY h", [$from, $to]) as $x) {
    $c = $chan($x['h']); $src[$c] = ['u' => ($src[$c]['u'] ?? 0) + $x['u'], 's' => ($src[$c]['s'] ?? 0) + $x['s'], 'sec' => ($src[$c]['sec'] ?? 0) + $x['sec']];
}
uasort($src, function ($a, $b) { return $b['u'] <=> $a['u']; });
/* devices */
$dev = ['mobile' => 0, 'desktop' => 0, 'tablet' => 0]; foreach (adm_q($pdo, "SELECT device, COUNT(DISTINCT $VK) u FROM hv_pageviews WHERE $W GROUP BY device", [$from, $to]) as $x) if (isset($dev[$x['device']])) $dev[$x['device']] = (int)$x['u'];
/* pages */
$pages = adm_q($pdo, "SELECT path, COUNT(*) v, COUNT(DISTINCT $VK) u, AVG(NULLIF(seconds,0)) sec, AVG(NULLIF(scroll,0)) sc FROM hv_pageviews WHERE $W GROUP BY path ORDER BY v DESC LIMIT 15", [$from, $to])->fetchAll(PDO::FETCH_ASSOC);
/* results */
$res = ['greet' => 0, 'paid' => 0, 'amt' => 0, 'members' => 0];
try { $res['greet'] = (int)adm_val($pdo, 'SELECT COUNT(*) FROM hv_ix_experiences WHERE created_at BETWEEN ? AND ?', [$from, $to]); } catch (Throwable $e) {}
try { $p = adm_q($pdo, "SELECT COUNT(*), COALESCE(SUM(COALESCE(agreed_price, est_price)),0) FROM hv_ix_orders WHERE status IN ('verification_pending','paid','in_progress','delivered') AND COALESCE(upi_ref_at, updated_at) BETWEEN ? AND ?", [$from, $to])->fetch(PDO::FETCH_NUM); $res['paid'] = (int)$p[0]; $res['amt'] = (int)$p[1]; } catch (Throwable $e) {}
try { $res['members'] = (int)adm_val($pdo, 'SELECT COUNT(*) FROM hv_members WHERE created_at BETWEEN ? AND ?', [$from, $to]); } catch (Throwable $e) {}

/* ---------- helpers ---------- */
$fmtT = function ($s) { $s = (int)round($s); return $s >= 3600 ? floor($s / 3600) . 'h ' . floor($s % 3600 / 60) . 'm' : ($s >= 60 ? floor($s / 60) . 'm ' . str_pad((string)($s % 60), 2, '0', STR_PAD_LEFT) . 's' : $s . 's'); };
$delta = function ($a, $b, $inv = false) { if (!$b) return $a ? '<span class="an-d an-up">new</span>' : ''; $p = ($a - $b) / $b * 100; $up = $p >= 0; return '<span class="an-d ' . ($up xor $inv ? 'an-up' : 'an-down') . '">' . ($up ? '▲' : '▼') . ' ' . number_format(abs($p), abs($p) < 10 ? 1 : 0) . '%</span>'; };
$chart = function (array $labels, array $series, $unit = '') {
    $W = 860; $H = 280; $L = 46; $R = 16; $T = 18; $B = 38; $n = count($labels); if (!$n) return '';
    $max = 1; foreach ($series as $s) foreach ($s['v'] as $v) $max = max($max, $v);
    $step = pow(10, floor(log10($max))); foreach ([1, 2, 2.5, 5, 10] as $m) if ($max <= $m * $step * 4) { $step *= $m; break; } $top = ceil($max / $step) * $step; if ($top <= 0) $top = 1;
    $x = function ($i) use ($n, $L, $R, $W) { return $n === 1 ? ($L + $W - $R) / 2 : $L + ($W - $L - $R) * $i / ($n - 1); };
    $y = function ($v) use ($top, $T, $H, $B) { return $T + ($H - $T - $B) * (1 - $v / $top); };
    $o = '<svg class="an-chart" viewBox="0 0 ' . $W . ' ' . $H . '" role="img" aria-label="Trend chart"><defs>';
    foreach ($series as $k => $s) $o .= '<linearGradient id="anG' . $k . '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' . $s['c'] . '" stop-opacity=".22"/><stop offset="1" stop-color="' . $s['c'] . '" stop-opacity="0"/></linearGradient>';
    $o .= '</defs>';
    for ($v = 0; $v <= $top + 1e-9; $v += $step) { $yy = round($y($v), 1); $o .= '<line x1="' . $L . '" x2="' . ($W - $R) . '" y1="' . $yy . '" y2="' . $yy . '" class="an-grid"/><text x="' . ($L - 8) . '" y="' . ($yy + 4) . '" class="an-ax" text-anchor="end">' . e(number_format($v, $step < 1 ? 1 : 0)) . '</text>'; }
    $every = max(1, (int)ceil($n / 9));
    for ($i = 0; $i < $n; $i += $every) $o .= '<text x="' . round($x($i), 1) . '" y="' . ($H - 12) . '" class="an-ax" text-anchor="middle">' . e($labels[$i]) . '</text>';
    foreach ($series as $k => $s) {
        $pts = []; foreach ($s['v'] as $i => $v) $pts[] = round($x($i), 1) . ',' . round($y($v), 1);
        if ($k === 0 && $n > 1) $o .= '<polygon points="' . round($x(0), 1) . ',' . ($H - $B) . ' ' . implode(' ', $pts) . ' ' . round($x($n - 1), 1) . ',' . ($H - $B) . '" fill="url(#anG' . $k . ')"/>';
        $o .= '<polyline points="' . implode(' ', $pts) . '" fill="none" stroke="' . $s['c'] . '" stroke-width="' . ($k ? 2 : 2.6) . '" stroke-linejoin="round" stroke-linecap="round"' . (!empty($s['dash']) ? ' stroke-dasharray="5 5"' : '') . '/>';
        if ($n <= 45) foreach ($s['v'] as $i => $v) $o .= '<circle cx="' . round($x($i), 1) . '" cy="' . round($y($v), 1) . '" r="3.4" fill="#fff" stroke="' . $s['c'] . '" stroke-width="2"><title>' . e($labels[$i] . ' · ' . $s['n'] . ': ' . number_format($v, $v == (int)$v ? 0 : 1) . $unit) . '</title></circle>';
    }
    return $o . '</svg>';
};
$hbar = function ($label, $val, $max, $note = '', $tone = 'blue') { $w = $max ? max(2, round($val / $max * 100, 1)) : 0;
    return '<div class="an-hb"><div class="an-hb-top"><span>' . $label . '</span><b>' . e($note) . '</b></div><div class="an-hb-track"><i class="an-tone-' . $tone . '" style="width:' . $w . '%"></i></div></div>'; };
$qs = function ($p) use ($r, $g) { $b = ['r' => $r, 'g' => $g]; if ($r === 'custom') { $b['from'] = $_GET['from'] ?? ''; $b['to'] = $_GET['to'] ?? ''; } return adm_url('insights', array_merge($b, $p)); };

adm_head($pdo, 'insights', 'Visitor insights');
adm_page_head('Visitor insights', 'Who visits H View, where they come from, how long they stay and whether they come back. Real readers only: bots, previews and the team are left out.', []);
?>
<style>
.an-bar{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;margin:0 0 18px}
.an-chips{display:flex;flex-wrap:wrap;gap:6px}
.an-chips a{display:inline-flex;align-items:center;min-height:36px;padding:0 14px;border-radius:999px;border:1px solid var(--line);background:var(--surface);color:var(--ink-2);font-weight:600;font-size:13.5px;text-decoration:none}
.an-chips a:hover{background:var(--hover);color:var(--blue)}
.an-chips a.is-on{background:var(--grad);border-color:transparent;color:#fff;box-shadow:0 6px 16px -8px rgba(101,83,217,.7)}
.an-custom{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.an-custom input{min-height:36px;padding:0 10px;border:1px solid var(--line);border-radius:var(--r-sm);background:var(--surface);font:inherit;font-size:13.5px;color:var(--ink)}
.an-seg{display:inline-flex;padding:3px;border-radius:999px;background:var(--line-2)}
.an-seg a{min-height:30px;display:inline-flex;align-items:center;padding:0 12px;border-radius:999px;font-size:13px;font-weight:600;color:var(--muted);text-decoration:none}
.an-seg a.is-on{background:var(--surface);color:var(--ink);box-shadow:var(--shadow)}
.an-period{margin:0 0 16px;color:var(--muted);font-size:13.5px}
.an-period b{color:var(--ink)}
.an-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(178px,1fr));gap:14px;margin-bottom:18px}
.an-kpi{position:relative;padding:18px 18px 16px;border-radius:var(--r-lg);background:var(--surface);border:1px solid var(--line);box-shadow:var(--shadow);overflow:hidden}
.an-kpi:before{content:'';position:absolute;left:0;top:0;right:0;height:3px;background:var(--grad);opacity:.85}
.an-kpi small{display:block;font-size:12.5px;font-weight:600;color:var(--muted);letter-spacing:.01em}
.an-kpi b{display:block;margin:8px 0 6px;font:600 28px/1.1 var(--font);color:var(--ink);letter-spacing:-.02em}
.an-kpi em{font-style:normal;font-size:12.5px;color:var(--muted)}
.an-d{display:inline-block;margin-right:6px;padding:2px 7px;border-radius:999px;font-size:11.5px;font-weight:700}
.an-up{background:var(--soft-green);color:var(--good)}.an-down{background:#FEF0F3;color:var(--bad)}
.an-live{display:inline-flex;align-items:center;gap:8px}.an-dot{width:9px;height:9px;border-radius:50%;background:#12B76A;box-shadow:0 0 0 4px rgba(18,183,106,.18)}
.an-grid2{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(0,1fr);gap:18px;margin-bottom:18px}
.an-grid3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px;margin-bottom:18px}
@media (max-width:1100px){.an-grid2,.an-grid3{grid-template-columns:1fr}}
.an-card{background:var(--surface);border:1px solid var(--line);border-radius:var(--r-lg);box-shadow:var(--shadow);padding:20px 22px 22px}
.an-card h2{margin:0;font:600 16px/1.3 var(--font);color:var(--ink)}
.an-card .an-sub{margin:4px 0 16px;font-size:13px;color:var(--muted)}
.an-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap}
.an-legend{display:flex;gap:14px;flex-wrap:wrap;font-size:12.5px;color:var(--ink-2)}
.an-legend i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:6px;vertical-align:-1px}
.an-chart{width:100%;height:auto;display:block}
.an-chart .an-grid{stroke:var(--line-2);stroke-width:1}
.an-chart .an-ax{font:11px var(--font);fill:var(--faint)}
.an-hb{margin:0 0 12px}.an-hb:last-child{margin-bottom:0}
.an-hb-top{display:flex;justify-content:space-between;gap:10px;font-size:13.5px;color:var(--ink-2);margin-bottom:6px}
.an-hb-top b{font-weight:600;color:var(--ink);white-space:nowrap}
.an-hb-track{height:9px;border-radius:999px;background:var(--line-2);overflow:hidden}
.an-hb-track i{display:block;height:100%;border-radius:999px}
.an-tone-blue{background:linear-gradient(90deg,#1E4CFF,#6553D9)}.an-tone-pink{background:linear-gradient(90deg,#6553D9,#D81B76)}.an-tone-green{background:linear-gradient(90deg,#12B76A,#067647)}
.an-cols{display:flex;align-items:flex-end;gap:6px;height:150px;padding-top:8px}
.an-cols div{flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;height:100%;justify-content:flex-end}
.an-cols i{display:block;width:100%;max-width:46px;border-radius:8px 8px 3px 3px;background:var(--grad);min-height:3px}
.an-cols span{font-size:11px;color:var(--faint);white-space:nowrap}
.an-cols b{font-size:11.5px;color:var(--ink-2);font-weight:600}
.an-hours{display:grid;grid-template-columns:repeat(24,1fr);gap:3px;align-items:end;height:110px}
.an-hours i{display:block;border-radius:4px 4px 2px 2px;background:linear-gradient(180deg,#6553D9,#1E4CFF);min-height:3px}
.an-hours-x{display:grid;grid-template-columns:repeat(24,1fr);gap:3px;margin-top:6px;font-size:10.5px;color:var(--faint);text-align:center}
.an-donut{display:flex;align-items:center;gap:22px;flex-wrap:wrap}
.an-donut svg{width:132px;height:132px;flex:none}
.an-donut ul{list-style:none;margin:0;padding:0;display:grid;gap:10px;font-size:13.5px;color:var(--ink-2)}
.an-donut li b{display:block;font-size:20px;color:var(--ink);font-weight:600}
.an-donut li i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:6px}
.an-flag{font-size:18px;margin-right:8px;vertical-align:-2px}
.an-results{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}
.an-results div{padding:14px 16px;border-radius:var(--r);background:var(--soft-violet)}
.an-results div:nth-child(2){background:var(--soft-green)}.an-results div:nth-child(3){background:var(--soft-pink)}.an-results div:nth-child(4){background:var(--soft-blue)}
.an-results small{display:block;font-size:12.5px;color:var(--muted);font-weight:600}.an-results b{display:block;margin-top:6px;font-size:22px;color:var(--ink);font-weight:600}
.an-table td,.an-table th{padding:10px 12px}
.an-path{display:inline-block;max-width:340px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:bottom}
.an-note{margin:18px 2px 0;font-size:12.5px;color:var(--faint);line-height:1.55}
</style>

<div class="an-bar">
  <nav class="an-chips" aria-label="Period"><?php foreach ($ranges as $k => $l): ?><a href="<?=e(adm_url('insights', ['r' => $k]))?>"<?=$r === $k ? ' class="is-on" aria-current="true"' : ''?>><?=e($l)?></a><?php endforeach ?></nav>
  <form class="an-custom" method="get" action="/admin/"><input type="hidden" name="m" value="dashboard"><input type="hidden" name="go" value="insights"><input type="hidden" name="r" value="custom">
    <input type="date" name="from" value="<?=e($f->format('Y-m-d'))?>" aria-label="From"><span class="adm-muted">to</span><input type="date" name="to" value="<?=e($t->format('Y-m-d'))?>" aria-label="To"><button class="adm-btn adm-btn-soft">Apply</button></form>
</div>
<p class="an-period">Showing <b><?=e($f->format('j M Y'))?><?=$days > 1 ? ' – ' . e($t->format('j M Y')) : ''?></b> (<?=$days?> day<?=$days > 1 ? 's' : ''?>), compared with the <?=$days?> day<?=$days > 1 ? 's' : ''?> before. <span class="an-live"><span class="an-dot"></span><b><?=(int)$live?></b> on the site right now</span></p>

<div class="an-kpis">
  <div class="an-kpi"><small>Visitors</small><b><?=number_format((int)$now['u'])?></b><em><?=$delta($now['u'], $prev['u'])?>unique people</em></div>
  <div class="an-kpi"><small>Sessions</small><b><?=number_format((int)$now['s'])?></b><em><?=$delta($now['s'], $prev['s'])?>visits to the site</em></div>
  <div class="an-kpi"><small>Avg. time per session</small><b><?=e($fmtT($now['avg']))?></b><em><?=$delta($now['avg'], $prev['avg'])?>on screen, not idle</em></div>
  <div class="an-kpi"><small>Page views</small><b><?=number_format((int)$now['v'])?></b><em><?=$delta($now['v'], $prev['v'])?><?=$now['s'] ? number_format($now['v'] / $now['s'], 1) : 0?> pages per session</em></div>
  <div class="an-kpi"><small>Returning visitors</small><b><?=number_format($retV + $cameBack)?></b><em><?=number_format($newV)?> new · <?=number_format($cameBack)?> came back in this period</em></div>
  <div class="an-kpi"><small>Engaged visits</small><b><?=number_format($now['eng'] * 100, 0)?>%</b><em><?=$delta($now['eng'], $prev['eng'])?>stayed 5 s or scrolled</em></div>
</div>

<div class="an-grid2">
  <section class="an-card">
    <div class="an-head"><div><h2>Visitors and sessions</h2><p class="an-sub">By <?=e($g)?>. Hover a point for the exact number.</p></div>
      <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap"><div class="an-legend"><span><i style="background:#1E4CFF"></i>Visitors</span><span><i style="background:#D81B76"></i>Sessions</span></div>
      <nav class="an-seg" aria-label="Group by"><?php foreach (['day' => 'Day', 'week' => 'Week', 'month' => 'Month'] as $k => $l): ?><a href="<?=e($qs(['g' => $k]))?>"<?=$g === $k ? ' class="is-on"' : ''?>><?=$l?></a><?php endforeach ?></nav></div></div>
    <?=$chart($labels, [['n' => 'Visitors', 'v' => $sU, 'c' => '#1E4CFF'], ['n' => 'Sessions', 'v' => $sS, 'c' => '#D81B76']])?>
  </section>
  <section class="an-card">
    <h2>New vs returning</h2><p class="an-sub">Visitors we have seen before, counted from 24 Nov 2026.</p>
    <?php $tot = max(1, $newV + $retV); $c1 = round($newV / $tot * 100, 1); $circ = 2 * M_PI * 52; ?>
    <div class="an-donut"><svg viewBox="0 0 132 132" aria-hidden="true"><circle cx="66" cy="66" r="52" fill="none" stroke="#F2EFFE" stroke-width="18"/>
      <circle cx="66" cy="66" r="52" fill="none" stroke="#6553D9" stroke-width="18" stroke-dasharray="<?=round($circ * $c1 / 100, 2)?> <?=round($circ, 2)?>" transform="rotate(-90 66 66)" stroke-linecap="butt"/>
      <circle cx="66" cy="66" r="52" fill="none" stroke="#D81B76" stroke-width="18" stroke-dasharray="<?=round($circ * (100 - $c1) / 100, 2)?> <?=round($circ, 2)?>" stroke-dashoffset="<?=-round($circ * $c1 / 100, 2)?>" transform="rotate(-90 66 66)"/>
      <text x="66" y="62" text-anchor="middle" style="font:600 20px var(--font);fill:var(--ink)"><?=number_format($newV + $retV)?></text><text x="66" y="80" text-anchor="middle" style="font:11px var(--font);fill:var(--muted)">tracked</text></svg>
      <ul><li><i style="background:#6553D9"></i>New<b><?=number_format($newV)?></b></li><li><i style="background:#D81B76"></i>Returning<b><?=number_format($retV)?></b></li><li><i style="background:#12B76A"></i>Came back in this period<b><?=number_format($cameBack)?></b></li></ul></div>
    <h2 style="margin-top:22px">Devices</h2><p class="an-sub">Visitors by device.</p>
    <?php $dm = max(1, max($dev)); foreach (['mobile' => 'Mobile', 'desktop' => 'Desktop', 'tablet' => 'Tablet'] as $k => $l) echo $hbar($l, $dev[$k], $dm, number_format($dev[$k]) . ' · ' . number_format($dev[$k] / max(1, array_sum($dev)) * 100) . '%', $k === 'mobile' ? 'pink' : 'blue'); ?>
  </section>
</div>

<div class="an-grid2">
  <section class="an-card">
    <h2>Average time per session</h2><p class="an-sub">Minutes on screen per session, by <?=e($g)?>.</p>
    <?=$chart($labels, [['n' => 'Minutes', 'v' => $sT, 'c' => '#6553D9']], ' min')?>
  </section>
  <section class="an-card">
    <h2>How long sessions last</h2><p class="an-sub">Each bar is a share of all sessions.</p>
    <?php $lt = max(1, array_sum(array_map('intval', $len))); $lm = max(1, max(array_map('intval', $len))); ?>
    <div class="an-cols"><?php foreach ($len as $i => $v): ?><div title="<?=e($lenL[$i] . ': ' . number_format((int)$v) . ' sessions')?>"><b><?=round((int)$v / $lt * 100)?>%</b><i style="height:<?=max(2, round((int)$v / $lm * 100))?>%"></i><span><?=e($lenL[$i])?></span></div><?php endforeach ?></div>
  </section>
</div>

<div class="an-grid3">
  <section class="an-card">
    <h2>Countries</h2><p class="an-sub">Visitors and average time per session.</p>
    <?php $cm = max(1, (int)($ctry[0]['u'] ?? 1)); foreach ($ctry as $x) echo $hbar('<span class="an-flag">' . hv_an_flag($x['cc']) . '</span>' . e($x['cc'] !== '' ? hv_an_country_name($x['cc']) : 'Not known yet'), (int)$x['u'], $cm, number_format((int)$x['u']) . ' · ' . $fmtT($x['s'] ? $x['sec'] / $x['s'] : 0)); ?>
    <?php if (!$ctry): ?><p class="adm-muted">No visits in this period.</p><?php endif ?>
  </section>
  <section class="an-card">
    <h2>Where visitors come from</h2><p class="an-sub">Visitors and average time per session.</p>
    <?php $sm = max(1, (int)(reset($src)['u'] ?? 1)); $i = 0; foreach ($src as $n => $x) { if ($i++ >= 10) break; echo $hbar(e($n), $x['u'], $sm, number_format($x['u']) . ' · ' . $fmtT($x['s'] ? $x['sec'] / $x['s'] : 0), 'pink'); } ?>
    <?php if (!$src): ?><p class="adm-muted">No visits in this period.</p><?php endif ?>
  </section>
  <section class="an-card">
    <h2>When people visit</h2><p class="an-sub">Sessions by hour of the day (India time).</p>
    <?php $hm = max(1, max($hrs)); ?>
    <div class="an-hours"><?php foreach ($hrs as $h => $v): ?><i style="height:<?=max(3, round($v / $hm * 100))?>%" title="<?=e(date('g a', mktime($h, 0)) . ': ' . number_format($v) . ' sessions')?>"></i><?php endforeach ?></div>
    <div class="an-hours-x"><?php for ($h = 0; $h < 24; $h++): ?><span><?=$h % 6 === 0 ? e(date('ga', mktime($h, 0))) : ''?></span><?php endfor ?></div>
    <?php $peak = array_search(max($hrs), $hrs, true); ?><p class="an-sub" style="margin:14px 0 0">Busiest hour: <b style="color:var(--ink)"><?=e(date('g a', mktime((int)$peak, 0)) . ' – ' . date('g a', mktime(((int)$peak + 1) % 24, 0)))?></b></p>
  </section>
</div>

<section class="an-card" style="margin-bottom:18px">
  <h2>What the visits turned into</h2><p class="an-sub">In the same period.</p>
  <div class="an-results">
    <div><small>Greetings created</small><b><?=number_format($res['greet'])?></b></div>
    <div><small>Greeting payments</small><b><?=number_format($res['paid'])?> · ₹<?=number_format($res['amt'])?></b></div>
    <div><small>New members</small><b><?=number_format($res['members'])?></b></div>
    <div><small>Greetings per 100 visitors</small><b><?=$now['u'] ? number_format($res['greet'] / $now['u'] * 100, 1) : '0'?></b></div>
  </div>
</section>

<section class="an-card" style="padding:20px 0 6px">
  <div style="padding:0 22px"><h2>Top pages</h2><p class="an-sub">Most viewed pages, with time on page and how far people scrolled.</p></div>
  <div class="adm-table-wrap"><table class="adm-table an-table"><thead><tr><th>Page</th><th class="adm-num">Views</th><th class="adm-num">Visitors</th><th class="adm-num">Avg. time</th><th class="adm-num">Scrolled</th></tr></thead><tbody>
  <?php foreach ($pages as $x): ?><tr><td><a class="adm-link an-path" href="<?=e($x['path'])?>" target="_blank" rel="noopener" title="<?=e($x['path'])?>"><?=e($x['path'])?></a></td><td class="adm-num"><?=number_format((int)$x['v'])?></td><td class="adm-num"><?=number_format((int)$x['u'])?></td><td class="adm-num"><?=e($fmtT((float)$x['sec']))?></td><td class="adm-num"><?=$x['sc'] !== null ? round((float)$x['sc']) . '%' : '—'?></td></tr><?php endforeach ?>
  <?php if (!$pages): ?><tr><td colspan="5" class="adm-empty">No visits in this period.</td></tr><?php endif ?>
  </tbody></table></div>
</section>
<p class="an-note">Time is counted only while the page is open and on screen; idle background tabs do not add time. Sessions end after 30 minutes without activity. Exact sessions, returning visitors and countries start on 24 Nov 2026; before that a session is one visitor-day and the country is not known. IP to country by <a class="adm-link" href="https://db-ip.com" target="_blank" rel="noopener">DB-IP</a> (CC BY 4.0); IP addresses are never stored.</p>
<?php adm_foot();
