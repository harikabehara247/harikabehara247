<?php
/* Builds admin-core/data/geo/v4.bin and v6.bin from the DB-IP Lite country CSVs (CC BY 4.0),
 * mirrored at github.com/sapics/ip-location-db. Run from the site root: php admin-core/geo-build.php
 * Record layout: start, end (4 or 16 bytes, network order) and a 2-letter country code; neighbouring
 * ranges of the same country are merged. Re-run monthly to refresh. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$dir = __DIR__ . '/data/geo'; if (!is_dir($dir)) mkdir($dir, 0755, true);
foreach (['v4' => 'ipv4', 'v6' => 'ipv6'] as $k => $f) {
    $url = "https://raw.githubusercontent.com/sapics/ip-location-db/main/dbip-country/dbip-country-$f.csv";
    $tmp = "$dir/$k.csv"; $ch = curl_init($url); $fh = fopen($tmp, 'wb');
    curl_setopt_array($ch, [CURLOPT_FILE => $fh, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 180]); $ok = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch); fclose($fh);
    if (!$ok || $code !== 200 || filesize($tmp) < 100000) { echo "$k: download failed ($code)\n"; @unlink($tmp); continue; }
    $in = fopen($tmp, 'rb'); $out = fopen("$dir/$k.bin.new", 'wb'); $n = 0; $prev = null;
    while (($row = fgetcsv($in, 200, ',', '"', '')) !== false) {
        if (count($row) < 3) continue; $s = @inet_pton(trim($row[0])); $e = @inet_pton(trim($row[1])); $cc = strtoupper(trim($row[2]));
        if ($s === false || $e === false || strlen($s) !== strlen($e) || !preg_match('/^[A-Z]{2}$/', $cc)) continue;
        if ($prev && $prev[2] === $cc && strlen($prev[0]) === strlen($s)) {
            $next = $prev[1]; for ($i = strlen($next) - 1; $i >= 0; $i--) { $b = ord($next[$i]) + 1; $next[$i] = chr($b & 255); if ($b < 256) break; }
            if ($next === $s) { $prev[1] = $e; continue; }
        }
        if ($prev) { fwrite($out, $prev[0] . $prev[1] . $prev[2]); $n++; }
        $prev = [$s, $e, $cc];
    }
    if ($prev) { fwrite($out, $prev[0] . $prev[1] . $prev[2]); $n++; }
    fclose($in); fclose($out); unlink($tmp); rename("$dir/$k.bin.new", "$dir/$k.bin");
    echo "$k: $n ranges, " . filesize("$dir/$k.bin") . " bytes\n";
}
