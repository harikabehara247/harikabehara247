/* =====================================================================
 * HView Interactive — packaged designs (24 Nov 2026)
 * Self-contained greetings in /assets/ixpack/<product>--<design>/index.html,
 * shown in a same-site iframe. Names, message and photo go in through the
 * URL hash (window.HV); the page reports progress with postMessage
 * {hv:'step'} and {hv:'done'}, which opens the share/reply panel.
 * ===================================================================== */
(function () {
  'use strict';
  var X = window.IXScenes; if (!X || !X.define) return;
  var KEYS = {
    'greeting-card': ['crane', 'popup3d', 'flowers', 'gildcrane', 'sculpt', 'vellum']
  };
  function make(prod, key) {
    return function (kit) {
      var el = kit.stage.el, d = kit.data || {}, fr = null, done = false, onMsg = null;
      function build() {
        if (fr) fr.remove();
        var hv = { to: d.to || 'Ananya', from: d.from || '', msg: d.msg || '', photo: d.photoUrl || d.photo || '', age: d.age || '', date: d.date || '', autoplay: kit.mode !== 'recipient', muted: kit.mode !== 'recipient' };
        fr = document.createElement('iframe');
        fr.className = 'ix-pack-frame'; fr.title = 'Interactive greeting'; fr.setAttribute('allow', 'autoplay; vibrate');
        fr.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;border:0;z-index:4;background:#0b0806;display:block';
        fr.src = '/assets/ixpack/' + prod + '--' + key + '/index.html#' + encodeURIComponent(JSON.stringify(hv));
        el.appendChild(fr);
      }
      return {
        resize: function () {},
        start: function () {
          done = false; build(); kit.hint('');
          onMsg = function (e) {
            if (!fr || e.source !== fr.contentWindow || !e.data || typeof e.data !== 'object') return;
            if (e.data.hv === 'step') kit.ev && kit.ev('step', { x: String(e.data.name || '').slice(0, 40) });
            if (e.data.hv === 'done' && !done) { done = true; setTimeout(function () { kit.reveal(); }, 900); }
          };
          window.addEventListener('message', onMsg);
        },
        update: function () {},
        draw: function () { var g = kit.stage.ctx; if (g) { g.fillStyle = '#0b0806'; g.fillRect(0, 0, kit.W(), kit.H()); } },
        destroy: function () { if (onMsg) window.removeEventListener('message', onMsg); if (fr) fr.remove(); fr = null; }
      };
    };
  }
  Object.keys(KEYS).forEach(function (p) { KEYS[p].forEach(function (k) { X.define(p + ':' + k, make(p, k)); }); });
})();
