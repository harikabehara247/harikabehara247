/* H View Black Friday sale (r78, 25 Nov 2026): a slim strip at the top of every page and one well-timed offer card.
 * Loaded by app.php only while the sale runs (setting bf_until) and never for paying members.
 * Card rules: never on arrival; after ~20 s of reading plus some scrolling, or when a desktop visitor heads for the tabs;
 * at most once a day; one tap to close; centred card on desktop, bottom sheet on phones (no full-screen cover).
 * Views, clicks and closes are counted in hv_cta_clicks (placement bf_strip / bf_card) via /whatsapp/cta. */
(function () {
  'use strict';
  var d = document, w = window, path = location.pathname;
  if (w.__hvBf || /^\/(account|admin|business)\//.test(path)) return; w.__hvBf = 1;
  var END = new Date('2026-11-30T23:59:59+05:30').getTime();
  if (Date.now() > END) return;
  var URL = '/account/plan/?from=bf';
  var PLANS = [
    { k: 'bf3', m: 3, p: 199 }, { k: 'bf6', m: 6, p: 299, tag: 'Popular' },
    { k: 'bf8', m: 8, p: 399 }, { k: 'bf12', m: 12, p: 499, tag: 'Best value' }
  ];
  var PERKS = [
    ['✨', 'Premium wishes & invitations', 'Every premium design, birthdays to weddings, with no daily limit'],
    ['🎬', 'Photo-real animated surprises', 'Gift box, secret message, 3D pop-up card and photo stories'],
    ['🛠️', 'Premium tools, no daily limits', 'Plagiarism checker Pro, resume builder Pro and more (fair use)'],
    ['🚫', 'All free tools, zero ads', 'PDF, image, OCR and SEO tools, with no ads anywhere on H View']
  ];
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  function sess(k, v) { try { if (v === undefined) return sessionStorage.getItem(k); sessionStorage.setItem(k, v); } catch (e) { return null; } }
  function count(place, act) { try { var f = new FormData(); f.append('p', place); f.append('a', act); f.append('u', path.slice(0, 190)); navigator.sendBeacon && navigator.sendBeacon('/whatsapp/cta', f); } catch (e) {} }
  function left() {
    var s = Math.max(0, Math.floor((END - Date.now()) / 1000));
    return { d: Math.floor(s / 86400), h: Math.floor(s % 86400 / 3600), m: Math.floor(s % 3600 / 60), s: s % 60 };
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function css() {
    var c = d.createElement('style');
    c.textContent =
      '.hvbf-strip{position:relative;z-index:60;display:flex;align-items:center;justify-content:center;gap:10px 16px;flex-wrap:wrap;padding:8px 44px 8px 14px;background:linear-gradient(90deg,#0b0f1f,#1b2563 55%,#4b2a8f);color:#fff;font:500 14px/1.35 Inter,system-ui,sans-serif;text-align:center}' +
      '.hvbf-strip b{color:#ffd36b;letter-spacing:.04em}.hvbf-strip a{color:#0b0f1f;background:#ffd36b;border-radius:999px;padding:5px 14px;font-weight:700;text-decoration:none;white-space:nowrap}' +
      '.hvbf-strip time{font-variant-numeric:tabular-nums;opacity:.9}.hvbf-x{position:absolute;right:8px;top:50%;transform:translateY(-50%);width:30px;height:30px;border:0;border-radius:50%;background:rgba(255,255,255,.12);color:#fff;font-size:18px;line-height:1;cursor:pointer}' +
      '.hvbf-ov{position:fixed;inset:0;z-index:2147483000;background:rgba(8,10,24,.55);backdrop-filter:blur(3px);display:flex;align-items:center;justify-content:center;padding:18px;opacity:0;transition:opacity .25s}' +
      '.hvbf-ov.is-on{opacity:1}.hvbf-card{position:relative;width:min(560px,100%);max-height:92vh;overflow:auto;border-radius:24px;background:radial-gradient(120% 90% at 100% 0,#3b2a8f 0,#141a3d 45%,#0b0f1f 100%);color:#fff;box-shadow:0 30px 80px rgba(0,0,0,.45);padding:26px 24px 22px;font:15px/1.45 Inter,system-ui,sans-serif;transform:translateY(16px) scale(.98);transition:transform .3s cubic-bezier(.2,.8,.2,1)}' +
      '.hvbf-ov.is-on .hvbf-card{transform:none}.hvbf-card .hvbf-x{top:16px;transform:none;right:14px}' +
      '.hvbf-k{display:inline-block;font-size:12px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:#0b0f1f;background:#ffd36b;border-radius:999px;padding:4px 10px}' +
      '.hvbf-card h2{margin:12px 0 6px;font:800 26px/1.15 Inter,system-ui,sans-serif;color:#fff}.hvbf-card h2 em{font-style:normal;background:linear-gradient(90deg,#ffd36b,#ff8fc4);-webkit-background-clip:text;background-clip:text;color:transparent}' +
      '.hvbf-sub{margin:0 0 14px;color:#c9cdf0}.hvbf-cd{display:flex;gap:8px;margin:0 0 16px}.hvbf-cd span{flex:1;text-align:center;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);border-radius:12px;padding:7px 4px}' +
      '.hvbf-cd b{display:block;font-size:20px;font-variant-numeric:tabular-nums}.hvbf-cd small{font-size:11px;color:#aab0dd;text-transform:uppercase;letter-spacing:.08em}' +
      '.hvbf-perks{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:0 0 16px;padding:0;list-style:none}.hvbf-perks li{display:flex;gap:10px;align-items:flex-start;background:rgba(255,255,255,.06);border-radius:14px;padding:10px 12px}' +
      '.hvbf-perks i{font-style:normal;font-size:20px;line-height:1.2}.hvbf-perks b{display:block;font-size:14px}.hvbf-perks span{display:block;font-size:12.5px;color:#b8bde6;line-height:1.35}' +
      '.hvbf-plans{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:0 0 14px}.hvbf-plan{position:relative;border:1.5px solid rgba(255,255,255,.18);background:rgba(255,255,255,.04);color:#fff;border-radius:14px;padding:12px 6px 10px;text-align:center;cursor:pointer;font:inherit}' +
      '.hvbf-plan b{display:block;font-size:20px}.hvbf-plan small{display:block;font-size:12px;color:#b8bde6}.hvbf-plan em{position:absolute;top:-9px;left:50%;transform:translateX(-50%);white-space:nowrap;font-style:normal;font-size:10.5px;font-weight:700;color:#0b0f1f;background:#ffd36b;border-radius:999px;padding:2px 8px}' +
      '.hvbf-plan[aria-pressed=true]{border-color:#ffd36b;background:rgba(255,211,107,.12);box-shadow:0 0 0 3px rgba(255,211,107,.18)}' +
      '.hvbf-go{display:block;text-align:center;text-decoration:none;font-weight:800;font-size:16px;color:#0b0f1f;background:linear-gradient(90deg,#ffd36b,#ffb3d6);border-radius:14px;padding:14px}' +
      '.hvbf-fine{margin:10px 0 0;text-align:center;font-size:12px;color:#9ea4d6}.hvbf-later{background:none;border:0;color:#c9cdf0;text-decoration:underline;cursor:pointer;font:inherit;font-size:13px;display:block;margin:8px auto 0}' +
      '@media(max-width:640px){.hvbf-strip{font-size:12.5px;padding:7px 40px 7px 10px}.hvbf-strip .hvbf-long{display:none}.hvbf-ov{align-items:flex-end;padding:0}' +
      '.hvbf-card{width:100%;border-radius:22px 22px 0 0;padding:22px 16px 16px;max-height:88vh}.hvbf-card h2{font-size:22px}.hvbf-perks{grid-template-columns:1fr;gap:8px}.hvbf-perks li{padding:8px 10px}' +
      '.hvbf-plans{grid-template-columns:repeat(2,1fr);gap:12px 8px}.hvbf-cd b{font-size:17px}}';
    d.head.appendChild(c);
  }
  function strip() {
    if (sess('hvbf_strip_x')) return;
    var s = d.createElement('div'); s.className = 'hvbf-strip'; s.setAttribute('role', 'region'); s.setAttribute('aria-label', 'Black Friday offer');
    s.innerHTML = '<span><b>BLACK FRIDAY</b> <span class="hvbf-long">· All H View Premium: wishes, invitations &amp; tools, no limits, no ads ·</span> from ₹199</span><time aria-label="Time left"></time><a href="' + URL + '&amp;src=strip">Get the deal</a><button class="hvbf-x" type="button" aria-label="Close">×</button>';
    d.body.insertBefore(s, d.body.firstChild);
    var t = s.querySelector('time');
    function tick() { var l = left(); t.textContent = 'Ends in ' + (l.d ? l.d + 'd ' : '') + pad(l.h) + ':' + pad(l.m) + ':' + pad(l.s); }
    tick(); setInterval(tick, 1000);
    s.querySelector('a').addEventListener('click', function () { count('bf_strip', 'click'); });
    s.querySelector('.hvbf-x').addEventListener('click', function () { s.remove(); sess('hvbf_strip_x', '1'); count('bf_strip', 'close'); });
  }
  var shown = false;
  function card(why) {
    if (shown || d.querySelector('.hvbf-ov')) return; shown = true;
    if (Date.now() - (+store('hvbf_card_at') || 0) < 864e5) return;
    store('hvbf_card_at', String(Date.now())); count('bf_card', 'view');
    var pick = 'bf12';
    var ov = d.createElement('div'); ov.className = 'hvbf-ov'; ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-modal', 'true'); ov.setAttribute('aria-labelledby', 'hvbf-h');
    ov.innerHTML = '<div class="hvbf-card"><button class="hvbf-x" type="button" aria-label="Close">×</button>' +
      '<span class="hvbf-k">Black Friday sale</span><h2 id="hvbf-h">All of H View Premium, <em>from ₹199</em></h2>' +
      '<p class="hvbf-sub">Make every wish unforgettable and use every tool with no limits. One payment, nothing renews automatically.</p>' +
      '<div class="hvbf-cd" aria-label="Time left in the sale"><span><b data-u="d">0</b><small>days</small></span><span><b data-u="h">00</b><small>hours</small></span><span><b data-u="m">00</b><small>mins</small></span><span><b data-u="s">00</b><small>secs</small></span></div>' +
      '<ul class="hvbf-perks">' + PERKS.map(function (p) { return '<li><i aria-hidden="true">' + p[0] + '</i><div><b>' + p[1] + '</b><span>' + p[2] + '</span></div></li>'; }).join('') + '</ul>' +
      '<div class="hvbf-plans" role="group" aria-label="Choose how long">' + PLANS.map(function (p) {
        return '<button type="button" class="hvbf-plan" data-k="' + p.k + '" aria-pressed="' + (p.k === pick) + '">' + (p.tag ? '<em>' + p.tag + '</em>' : '') + '<b>₹' + p.p + '</b><small>' + p.m + ' months</small><small>₹' + Math.round(p.p / p.m) + '/month</small></button>';
      }).join('') + '</div>' +
      '<a class="hvbf-go" href="#">Get 12 months for ₹499 →</a>' +
      '<p class="hvbf-fine">Pay once by UPI · Premium starts right away · Offer ends Mon 30 Nov, 11:59 PM IST</p>' +
      '<button class="hvbf-later" type="button">Maybe later</button></div>';
    d.body.appendChild(ov);
    requestAnimationFrame(function () { ov.classList.add('is-on'); });
    var go = ov.querySelector('.hvbf-go');
    function setPick(k) {
      pick = k; var p = PLANS.filter(function (x) { return x.k === k; })[0];
      ov.querySelectorAll('.hvbf-plan').forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-k') === k ? 'true' : 'false'); });
      go.textContent = 'Get ' + p.m + ' months for ₹' + p.p + ' →'; go.href = URL + '&src=card&plan=' + k;
    }
    setPick(pick);
    ov.querySelectorAll('.hvbf-plan').forEach(function (b) { b.addEventListener('click', function () { setPick(b.getAttribute('data-k')); }); });
    var cd = {}; ov.querySelectorAll('[data-u]').forEach(function (b) { cd[b.getAttribute('data-u')] = b; });
    function tick() { var l = left(); cd.d.textContent = l.d; cd.h.textContent = pad(l.h); cd.m.textContent = pad(l.m); cd.s.textContent = pad(l.s); }
    tick(); var iv = setInterval(tick, 1000);
    function close(how) { clearInterval(iv); ov.classList.remove('is-on'); setTimeout(function () { ov.remove(); }, 250); d.removeEventListener('keydown', esc); count('bf_card', how); }
    function esc(e) { if (e.key === 'Escape') close('close'); }
    d.addEventListener('keydown', esc);
    ov.addEventListener('click', function (e) { if (e.target === ov) close('close'); });
    ov.querySelector('.hvbf-x').addEventListener('click', function () { close('close'); });
    ov.querySelector('.hvbf-later').addEventListener('click', function () { close('later'); });
    go.addEventListener('click', function () { count('bf_card', 'click_' + pick.replace('bf', 'm')); });
    go.focus({ preventScroll: true });
  }
  function watch() {
    /* card: ~20 s of visible reading plus 30% scroll (or 45 s on short pages), or desktop exit intent after 10 s */
    var seen = 0, deep = false, t0 = Date.now();
    w.addEventListener('scroll', function () { var h = d.documentElement; if ((h.scrollTop + innerHeight) / Math.max(1, h.scrollHeight) > 0.3) deep = true; }, { passive: true });
    var iv = setInterval(function () {
      if (d.visibilityState !== 'visible' || d.querySelector('.ix-sheet.is-open,.ix-hlp.is-open,[aria-modal=true]:not(.hvbf-ov)')) return;
      seen++; if ((seen >= 20 && deep) || seen >= 45) { clearInterval(iv); card('time'); }
    }, 1000);
    if (matchMedia('(pointer:fine)').matches) d.addEventListener('mouseout', function (e) { if (!e.relatedTarget && e.clientY < 8 && Date.now() - t0 > 10000) { clearInterval(iv); card('exit'); } });
  }
  function start() {
    /* never interrupt someone opening a greeting that was sent to them */
    if (w.IX && w.IX.mode === 'recipient') return;
    css(); strip(); watch();
  }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})();
