<?php
/* Referral wallet (r78, 25 Nov 2026). Opens at /admin/?m=dashboard&go=referrals
 * Withdrawal requests to pay by hand, every commission with its order, and the programme settings. Logic: ac-core/ref.php */
adm_require('referrals');
require_once dirname(HV_CORE) . '/ac-core/lib.php';
if (is_file(dirname(HV_CORE) . '/ac-core/mp.php')) require_once dirname(HV_CORE) . '/ac-core/mp.php';
require_once dirname(HV_CORE) . '/ac-core/ref.php';
ref_migrate($pdo);
$back = adm_url('referrals');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $do = (string)($_POST['do'] ?? ''); $id = (int)($_POST['id'] ?? 0);
    if ($do === 'paid') {
        $utr = substr(preg_replace('/[^A-Za-z0-9]/', '', (string)($_POST['utr'] ?? '')), 0, 40);
        $pdo->prepare("UPDATE hv_ref_payouts SET status='paid', utr=?, paid_at=?, note=? WHERE id=? AND status='requested'")->execute([$utr ?: null, ref_now(), 'Paid by ' . ($_SESSION['hv_user']['name'] ?? 'admin'), $id]);
        adm_log($pdo, 'referral_payout_paid', 'referrals', $id, $utr); adm_flash('success', 'Marked as paid.');
    } elseif ($do === 'reject') {
        $pdo->prepare("UPDATE hv_ref_payouts SET status='rejected', note=? WHERE id=? AND status='requested'")->execute([mb_substr((string)($_POST['note'] ?? 'Not paid'), 0, 250), $id]);
        adm_log($pdo, 'referral_payout_rejected', 'referrals', $id); adm_flash('success', 'Request declined. The amount is back in the member\'s wallet.');
    } elseif ($do === 'void') {
        $pdo->prepare("UPDATE hv_ref_earnings SET status='void' WHERE id=?")->execute([$id]);
        adm_log($pdo, 'referral_earning_void', 'referrals', $id); adm_flash('success', 'Commission removed.');
    } elseif ($do === 'restore') {
        $pdo->prepare("UPDATE hv_ref_earnings SET status='pending' WHERE id=?")->execute([$id]);
        adm_log($pdo, 'referral_earning_restore', 'referrals', $id); adm_flash('success', 'Commission restored.');
    } elseif ($do === 'settings') {
        $v = ['ref_on' => !empty($_POST['ref_on']) ? '1' : '0', 'ref_rate' => (string)max(0, min(50, (int)($_POST['ref_rate'] ?? 20))),
              'ref_min_payout' => (string)max(50, (int)($_POST['ref_min_payout'] ?? 500)), 'ref_hold_days' => (string)max(0, min(60, (int)($_POST['ref_hold_days'] ?? 7)))];
        site_settings_save($pdo, $v); adm_log($pdo, 'referral_settings', 'referrals', null, json_encode($v)); adm_flash('success', 'Settings saved.');
    }
    adm_redirect($back);
}

$k = $pdo->query("SELECT
   (SELECT COUNT(*) FROM hv_ref_payouts WHERE status='requested') reqn, (SELECT COALESCE(SUM(amount),0) FROM hv_ref_payouts WHERE status='requested') reqamt,
   (SELECT COALESCE(SUM(amount),0) FROM hv_ref_payouts WHERE status='paid') paid, (SELECT COUNT(*) FROM hv_ref_earnings WHERE status<>'void') sales,
   (SELECT COALESCE(SUM(amount),0) FROM hv_ref_earnings WHERE status<>'void') revenue, (SELECT COALESCE(SUM(commission),0) FROM hv_ref_earnings WHERE status<>'void') owed,
   (SELECT COUNT(*) FROM hv_ref_codes) links")->fetch(PDO::FETCH_ASSOC);
$req = $pdo->query("SELECT p.*, m.name, m.email FROM hv_ref_payouts p LEFT JOIN hv_members m ON m.id=p.member_id ORDER BY FIELD(p.status,'requested','paid','rejected'), p.id DESC LIMIT 60")->fetchAll(PDO::FETCH_ASSOC);
$earn = $pdo->query("SELECT e.*, r.name rname, r.email remail, b.name bname, b.email bemail, u.code ocode FROM hv_ref_earnings e LEFT JOIN hv_members r ON r.id=e.referrer_id LEFT JOIN hv_members b ON b.id=e.buyer_id LEFT JOIN hv_member_upgrades u ON u.id=e.order_id ORDER BY e.id DESC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
$top = $pdo->query("SELECT r.name, r.email, COUNT(*) n, SUM(e.commission) c FROM hv_ref_earnings e JOIN hv_members r ON r.id=e.referrer_id WHERE e.status<>'void' GROUP BY e.referrer_id ORDER BY c DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);

adm_head($pdo, 'referrals', 'Referral wallet');
adm_page_head('Referral wallet', 'Members who bought a plan share a private link and earn ' . (int)ref_set($pdo, 'ref_rate') . '% of each plan bought through it. Pay withdrawal requests by UPI, then mark them paid here. Members never see this on public pages.', []);
?>
<div class="adm-kpis">
  <?=adm_kpi('Withdrawals to pay', ref_rupees($k['reqamt']), (int)$k['reqn'] . ' request' . ((int)$k['reqn'] === 1 ? '' : 's'), 'inbox', null, 'pink')?>
  <?=adm_kpi('Sales from referrals', number_format((int)$k['sales']), '₹' . number_format((int)$k['revenue']) . ' revenue', 'chart', null, 'blue')?>
  <?=adm_kpi('Commission earned', ref_rupees($k['owed']), ref_rupees($k['paid']) . ' paid out', 'check', null, 'green')?>
  <?=adm_kpi('Referral links made', number_format((int)$k['links']), 'members who opened their wallet', 'link', null, 'violet')?>
</div>

<section class="adm-card adm-card-flush">
  <div class="rfa-h"><h2>Withdrawal requests</h2><small>Pay the amount to the UPI ID shown, then click <b>Mark paid</b> with the UTR.</small></div>
  <?php if (!$req): ?><p class="rfa-empty">No withdrawal requests yet.</p><?php else: ?>
  <div class="adm-table-wrap"><table class="adm-table"><thead><tr><th>Member</th><th>Amount</th><th>UPI ID</th><th>Asked</th><th>Status</th><th></th></tr></thead><tbody>
  <?php foreach ($req as $r): ?><tr>
    <td><b><?=e($r['name'] ?? '—')?></b><br><small><?=e($r['email'] ?? '')?></small></td><td><b><?=ref_rupees($r['amount'])?></b></td><td><code><?=e($r['upi'])?></code></td>
    <td><?=e(adm_date($r['created_at'], 'j M, g:i A'))?></td><td><?=adm_status(['requested' => 'open', 'paid' => 'done', 'rejected' => 'disabled'][$r['status']] ?? $r['status'])?><?=$r['utr'] ? '<br><small>UTR ' . e($r['utr']) . '</small>' : ''?></td>
    <td><?php if ($r['status'] === 'requested'): ?>
      <form method="post" class="adm-inline rfa-pay"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="do" value="paid"><input type="hidden" name="id" value="<?=(int)$r['id']?>"><input name="utr" placeholder="UTR (optional)" maxlength="40" aria-label="UTR"><button class="adm-btn adm-btn-primary">Mark paid</button></form>
      <?=adm_act_post('Decline', 'close', 'reject', ['id' => $r['id']], 'Decline this withdrawal? The amount goes back to the member\'s wallet.', true)?>
    <?php endif ?></td></tr><?php endforeach ?>
  </tbody></table></div><?php endif ?>
</section>

<section class="adm-card adm-card-flush">
  <div class="rfa-h"><h2>Commissions</h2><small>One row per plan bought through a link. A commission is added when you confirm the payment, and removed automatically if the order is rejected or refunded.</small></div>
  <?php if (!$earn): ?><p class="rfa-empty">No referral sales yet.</p><?php else: ?>
  <div class="adm-table-wrap"><table class="adm-table"><thead><tr><th>Date</th><th>Referred by</th><th>Buyer</th><th>Order</th><th>Paid</th><th>Commission</th><th>Status</th><th></th></tr></thead><tbody>
  <?php foreach ($earn as $r): $st = $r['status'] === 'void' ? 'Removed' : ($r['available_at'] > ref_now() ? 'Pending until ' . date('j M', strtotime($r['available_at'])) : 'Available'); ?><tr>
    <td><?=e(adm_date($r['created_at'], 'j M'))?></td><td><?=e($r['rname'] ?? '—')?><br><small><?=e($r['remail'] ?? '')?></small></td><td><?=e($r['bname'] ?? '—')?><br><small><?=e($r['bemail'] ?? '')?></small></td>
    <td><code><?=e($r['ocode'] ?? '')?></code><br><small><?=e($r['plan'])?></small></td><td>₹<?=number_format((int)$r['amount'])?></td><td><b><?=ref_rupees($r['commission'])?></b></td>
    <td><?=e($st)?><?=$r['flag'] ? '<br><small style="color:#b54708">⚠ ' . e($r['flag']) . '</small>' : ''?></td>
    <td><?=$r['status'] === 'void' ? adm_act_post('Restore', 'restore', 'restore', ['id' => $r['id']]) : adm_act_post('Remove', 'trash', 'void', ['id' => $r['id']], 'Remove this commission from the member\'s wallet?', true)?></td></tr><?php endforeach ?>
  </tbody></table></div><?php endif ?>
</section>

<div class="rfa-grid">
<section class="adm-card"><h2>Top referrers</h2>
  <?php if (!$top): ?><p class="rfa-empty" style="padding:0">Nobody yet.</p><?php else: ?><ol class="rfa-top"><?php foreach ($top as $t): ?><li><span><b><?=e($t['name'])?></b> <small><?=e($t['email'])?></small></span><span><?=(int)$t['n']?> sale<?=(int)$t['n'] === 1 ? '' : 's'?> · <b><?=ref_rupees($t['c'])?></b></span></li><?php endforeach ?></ol><?php endif ?>
</section>
<section class="adm-card"><h2>Programme settings</h2>
  <form method="post" class="rfa-set"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="do" value="settings">
    <label class="rfa-chk"><input type="checkbox" name="ref_on" value="1"<?=ref_set($pdo, 'ref_on') === '1' ? ' checked' : ''?>> Referral wallet is on (members who bought a plan see "Refer &amp; earn" in their account)</label>
    <label>Commission %<input type="number" name="ref_rate" min="0" max="50" value="<?=e(ref_set($pdo, 'ref_rate'))?>"></label>
    <label>Minimum withdrawal (₹)<input type="number" name="ref_min_payout" min="50" value="<?=e(ref_set($pdo, 'ref_min_payout'))?>"></label>
    <label>Hold before available (days)<input type="number" name="ref_hold_days" min="0" max="60" value="<?=e(ref_set($pdo, 'ref_hold_days'))?>"></label>
    <button class="adm-btn adm-btn-primary">Save settings</button></form>
</section></div>
<style>
.rfa-h{padding:18px 20px 6px}.rfa-h h2{margin:0 0 4px;font-size:1.05rem}.rfa-h small{color:var(--muted)}.rfa-empty{padding:6px 20px 20px;color:var(--muted)}
.rfa-pay input{width:150px;padding:7px 10px;border:1px solid var(--line);border-radius:10px;font:inherit;margin-right:6px}
.rfa-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.rfa-top{margin:0;padding-left:20px}.rfa-top li{display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid var(--line)}
.rfa-top small{color:var(--muted)}.rfa-set{display:grid;gap:12px}.rfa-set label{display:grid;gap:6px;font-weight:500}.rfa-set input[type=number]{padding:9px 12px;border:1px solid var(--line);border-radius:10px;font:inherit;max-width:200px}
.rfa-chk{display:flex!important;grid-template-columns:none;align-items:center;gap:8px;font-weight:400!important}
@media(max-width:900px){.rfa-grid{grid-template-columns:1fr}}
</style>
<?php adm_foot();
