<?php
/* usage: php patcher.php file.php anchors.json [--dry] — every anchor must match exactly once, or nothing is written */
[$_, $f, $j] = $argv; $dry = in_array('--dry', $argv, true);
$s = file_get_contents($f); $p = json_decode(file_get_contents($j), true); $bad = 0;
foreach ($p as $i => $x) { $n = substr_count($s, $x[0]); if ($n !== 1) { echo "ANCHOR $i x$n: " . substr($x[0], 0, 60) . "\n"; $bad++; } }
if ($bad) { echo "NOT CHANGED\n"; exit(1); }
foreach ($p as $x) $s = str_replace($x[0], $x[1], $s);
if (!$dry) file_put_contents($f, $s); echo ($dry ? 'dry ok ' : 'patched ') . $f . "\n";
