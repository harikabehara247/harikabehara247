<?php
/* =====================================================================
 * H View Membership — monthly plans for Interactive premium designs
 *
 *  Plans (hv_mp_plans, editable in Control Center → Members → Plans):
 *    free ₹0 · mini ₹199 (3 premium creations / IST day)
 *    plus ₹299 (5 / day) · max ₹499 (no daily cap, fair-use rate limit)
 *  A plan lasts 30 days from the payment date. Nothing renews by itself.
 *
 *  Payment: manual UPI. The member sends the UTR, the amount and the date
 *  (and optionally a screenshot) on the site or on WhatsApp. If the checks
 *  pass, the plan starts at once as PROVISIONAL (owner's choice, 12 Nov
 *  2026). The owner later uploads a bank/UPI statement; matching UTRs are
 *  confirmed, the rest can be cancelled with one click. A UTR or screenshot
 *  is never treated as proof of payment: provisional money is reported
 *  separately from confirmed revenue.
 *
 *  Premium creations are counted in hv_mp_credits (one row per member per
 *  IST day) with a conditional UPDATE inside the same transaction as the
 *  greeting insert, so parallel requests cannot go over the quota.
 * ===================================================================== */
if (defined('MP_LOADED')) return; define('MP_LOADED', 1);
const MP_SCHEMA = '1';

function mp_tz(){ static $z = null; return $z ?: ($z = new DateTimeZone('Asia/Kolkata')); }
function mp_now($fmt = 'Y-m-d H:i:s'){ return (new DateTime('now', mp_tz()))->format($fmt); }
function mp_today(){ return mp_now('Y-m-d'); }
function mp_ts($dt){ if (!$dt) return 0; try { return (new DateTime((string)$dt, mp_tz()))->getTimestamp(); } catch (Throwable $e) { return 0; } }
function mp_fmt($dt, $f = 'j M Y'){ $t = mp_ts($dt); return $t ? (new DateTime('@' . $t))->setTimezone(mp_tz())->format($f) : '—'; }
function mp_add_days($dt, $days){ $d = new DateTime((string)$dt, mp_tz()); $d->modify(sprintf('%+d days', (int)$days)); return $d->format('Y-m-d H:i:s'); }
function mp_midnight(){ $d = new DateTime('tomorrow', mp_tz()); return $d->format('Y-m-d H:i:s'); }

function mp_set(PDO $pdo, $key){
    $d = ['mp_enabled' => '1', 'mp_paywall_public' => '1', 'mp_provisional' => '1', 'mp_pay_window_hours' => '48', 'mp_proof_max_kb' => '3072',
          'mp_fair_use_hour' => '30', 'mp_remind_days' => '3,1', 'mp_recon_grace_days' => '7', 'mp_pc_tier_mini' => 'free', 'mp_pc_tier_plus' => 'free', 'mp_pc_tier_max' => 'free'];
    return (string)setting_value($pdo, $key, $d[$key] ?? '');
}

/* ---------------------------------------------------------------- schema */
function mp_col_exists(PDO $pdo, $t, $c){ $q = $pdo->prepare('SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?'); $q->execute([$t, $c]); return (bool)$q->fetchColumn(); }
function mp_migrate(PDO $pdo){
    static $done = false; if ($done) return; $done = true;
    if ((string)setting_value($pdo, 'mp_schema', '') === MP_SCHEMA) return;
    $cs = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $pdo->exec("CREATE TABLE IF NOT EXISTS hv_mp_plans (
        plan_key VARCHAR(12) NOT NULL PRIMARY KEY, name VARCHAR(40) NOT NULL, price INT NOT NULL DEFAULT 0, currency CHAR(3) NOT NULL DEFAULT 'INR',
        days SMALLINT NOT NULL DEFAULT 30, daily_quota INT NULL, tagline VARCHAR(160) NULL, benefits TEXT NULL,
        status VARCHAR(10) NOT NULL DEFAULT 'active', sort INT NOT NULL DEFAULT 0, updated_at DATETIME NULL) $cs");
    $pdo->exec("CREATE TABLE IF NOT EXISTS hv_mp_subs (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, member_id INT UNSIGNED NOT NULL, order_id INT UNSIGNED NULL, plan VARCHAR(12) NOT NULL,
        price INT NOT NULL DEFAULT 0, currency CHAR(3) NOT NULL DEFAULT 'INR', quota INT NULL, starts_at DATETIME NOT NULL, ends_at DATETIME NOT NULL,
        status VARCHAR(12) NOT NULL DEFAULT 'provisional', source VARCHAR(20) NOT NULL DEFAULT 'upi_provisional',
        reminded VARCHAR(20) NULL, note VARCHAR(255) NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
        INDEX(member_id, status), INDEX(status, ends_at), INDEX(order_id)) $cs");
    $pdo->exec("CREATE TABLE IF NOT EXISTS hv_mp_credits (
        member_id INT UNSIGNED NOT NULL, day DATE NOT NULL, used INT NOT NULL DEFAULT 0, PRIMARY KEY(member_id, day)) $cs");
    $pdo->exec("CREATE TABLE IF NOT EXISTS hv_mp_audit (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, member_id INT UNSIGNED NULL, order_id INT UNSIGNED NULL, sub_id INT UNSIGNED NULL,
        action VARCHAR(40) NOT NULL, detail VARCHAR(255) NULL, actor VARCHAR(120) NOT NULL DEFAULT 'system', created_at DATETIME NOT NULL,
        INDEX(member_id), INDEX(order_id), INDEX(created_at)) $cs");
    $pdo->exec("CREATE TABLE IF NOT EXISTS hv_mp_statement (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, utr VARCHAR(30) NOT NULL UNIQUE, amount DECIMAL(10,2) NULL, txn_at DATETIME NULL,
        raw VARCHAR(255) NULL, batch VARCHAR(20) NOT NULL, matched_order INT UNSIGNED NULL, created_at DATETIME NOT NULL, INDEX(batch)) $cs");
    /* orders reuse hv_member_upgrades (created by ac_migrate) */
    $cols = ['paid_amount' => 'INT NULL', 'paid_on' => 'DATETIME NULL', 'proof' => 'VARCHAR(255) NULL', 'source' => 'VARCHAR(12) NULL',
             'quota' => 'INT NULL', 'starts_at' => 'DATETIME NULL', 'ends_at' => 'DATETIME NULL', 'recon' => 'VARCHAR(20) NULL', 'recon_at' => 'DATETIME NULL', 'updated_at' => 'DATETIME NULL'];
    foreach ($cols as $c => $def) if (!mp_col_exists($pdo, 'hv_member_upgrades', $c)) { try { $pdo->exec("ALTER TABLE hv_member_upgrades ADD COLUMN $c $def"); } catch (Throwable $e) {} }
    try { $pdo->exec('CREATE INDEX idx_mu_utr ON hv_member_upgrades (upi_ref)'); } catch (Throwable $e) {}
    if (!mp_col_exists($pdo, 'hv_members', 'mp_blocked')) { try { $pdo->exec('ALTER TABLE hv_members ADD COLUMN mp_blocked TINYINT NOT NULL DEFAULT 0'); } catch (Throwable $e) {} }
    /* premium flag on greetings */
    if (!mp_col_exists($pdo, 'hv_ix_experiences', 'member_id')) { try { $pdo->exec('ALTER TABLE hv_ix_experiences ADD COLUMN member_id INT UNSIGNED NULL'); $pdo->exec('CREATE INDEX idx_hv_ix_experiences_member ON hv_ix_experiences (member_id)'); } catch (Throwable $e) {} }
    if (!mp_col_exists($pdo, 'hv_ix_experiences', 'tier')) { try { $pdo->exec("ALTER TABLE hv_ix_experiences ADD COLUMN tier VARCHAR(8) NOT NULL DEFAULT 'free'"); } catch (Throwable $e) {} }
    $seed = [
        ['free', 'Free', 0, null, 'Every free design, always free', ["All free designs in every occasion", "Name, message and theme personalisation", "Preview, reveal and share links", "Your greetings saved in your account"], 0],
        ['mini', 'Mini', 199, 3, 'For the occasional surprise', ["Full premium design library", "3 premium greetings a day", "Photo-led premium scenes where supported", "Free designs stay unlimited"], 10],
        ['plus', 'Plus', 299, 5, 'For birthdays, weddings and more', ["Everything in Mini", "5 premium greetings a day", "Richer photo, audio and background options where supported"], 20],
        ['max', 'Max', 499, null, 'For families, creators and small teams', ["Everything in Plus", "No daily cap on premium greetings (fair use)", "Every personalisation option we support"], 30],
    ];
    $ins = $pdo->prepare('INSERT IGNORE INTO hv_mp_plans (plan_key, name, price, daily_quota, tagline, benefits, sort, updated_at) VALUES (?,?,?,?,?,?,?,?)');
    foreach ($seed as $s) $ins->execute([$s[0], $s[1], $s[2], $s[3], $s[4], json_encode($s[5], JSON_UNESCAPED_UNICODE), $s[6], mp_now()]);
    site_settings_save($pdo, ['mp_schema' => MP_SCHEMA]);
}

/* ---------------------------------------------------------------- plans */
function mp_plans(PDO $pdo, $all = false){
    static $c = null; if ($c === null) { mp_migrate($pdo); $c = [];
        foreach ($pdo->query('SELECT * FROM hv_mp_plans ORDER BY sort, price') as $r) { $r['benefits'] = json_decode((string)$r['benefits'], true) ?: []; $r['daily_quota'] = $r['daily_quota'] === null ? null : (int)$r['daily_quota']; $r['price'] = (int)$r['price']; $r['days'] = (int)$r['days']; $c[$r['plan_key']] = $r; } }
    /* r78: during the Black Friday sale (setting bf_until) the plan page shows Free + the bf* plans only; afterwards bf* plans disappear. */
    $bf = mp_bf_on($pdo);
    return $all ? $c : array_filter($c, function ($p) use ($bf) { if ($p['status'] !== 'active') return false; $isBf = strpos($p['plan_key'], 'bf') === 0; return $bf ? ($isBf || $p['plan_key'] === 'free') : !$isBf; }, ARRAY_FILTER_USE_BOTH);
}
function mp_bf_on(PDO $pdo){ static $on = null; if ($on === null) { $u = (string)setting_value($pdo, 'bf_until', ''); $on = $u !== '' && $u >= mp_now(); } return $on; }
function mp_plan(PDO $pdo, $k){ $p = mp_plans($pdo, true); return $p[$k] ?? null; }
function mp_paid_keys(PDO $pdo){ return array_values(array_filter(array_keys(mp_plans($pdo, true)), function ($k) { return $k !== 'free'; })); }
function mp_quota_label($q){ return $q === null ? 'No daily cap' : $q . ' premium ' . ($q === 1 ? 'greeting' : 'greetings') . ' a day'; }

/* ---------------------------------------------------------------- audit */
function mp_audit(PDO $pdo, $action, array $ref = [], $detail = '', $actor = 'system'){
    try { $pdo->prepare('INSERT INTO hv_mp_audit (member_id, order_id, sub_id, action, detail, actor, created_at) VALUES (?,?,?,?,?,?,?)')
        ->execute([$ref['member'] ?? null, $ref['order'] ?? null, $ref['sub'] ?? null, $action, mb_substr((string)$detail, 0, 250), mb_substr((string)$actor, 0, 120), mp_now()]); } catch (Throwable $e) {}
}

/* ---------------------------------------------------------------- entitlement */
/* The subscription that is in force right now (provisional or confirmed), or null. */
function mp_current_sub(PDO $pdo, $memberId){
    if (!$memberId) return null; mp_migrate($pdo);
    $q = $pdo->prepare("SELECT * FROM hv_mp_subs WHERE member_id=? AND status IN ('provisional','active') AND starts_at<=? AND ends_at>? ORDER BY ends_at DESC LIMIT 1");
    $now = mp_now(); $q->execute([(int)$memberId, $now, $now]); return $q->fetch(PDO::FETCH_ASSOC) ?: null;
}
function mp_used_today(PDO $pdo, $memberId){ $q = $pdo->prepare('SELECT used FROM hv_mp_credits WHERE member_id=? AND day=?'); $q->execute([(int)$memberId, mp_today()]); return (int)$q->fetchColumn(); }
function mp_entitlement(PDO $pdo, $memberId){
    $e = ['plan' => 'free', 'name' => 'Free', 'active' => false, 'status' => null, 'ends_at' => null, 'quota' => 0, 'used' => 0, 'left' => 0, 'resets_at' => mp_midnight(), 'sub' => null];
    $s = $memberId ? mp_current_sub($pdo, $memberId) : null; if (!$s) return $e;
    $p = mp_plan($pdo, $s['plan']); $quota = $s['quota'] === null ? null : (int)$s['quota'];
    $used = mp_used_today($pdo, $memberId);
    return ['plan' => $s['plan'], 'name' => $p['name'] ?? ucfirst($s['plan']), 'active' => true, 'status' => $s['status'], 'ends_at' => $s['ends_at'],
            'quota' => $quota, 'used' => $used, 'left' => $quota === null ? null : max(0, $quota - $used), 'resets_at' => mp_midnight(), 'sub' => $s];
}
/* Atomic: take one premium credit for today. Call inside the transaction that saves the greeting. */
/* Create today's counter row first, OUTSIDE the transaction (avoids gap-lock deadlocks between parallel requests). */
function mp_credit_row(PDO $pdo, $memberId){ $pdo->prepare('INSERT IGNORE INTO hv_mp_credits (member_id, day, used) VALUES (?,?,0)')->execute([(int)$memberId, mp_today()]); }
function mp_take_credit(PDO $pdo, $memberId, $quota){
    $day = mp_today();
    if ($quota === null) { $q = $pdo->prepare('UPDATE hv_mp_credits SET used=used+1 WHERE member_id=? AND day=?'); $q->execute([(int)$memberId, $day]); return $q->rowCount() === 1; }
    $q = $pdo->prepare('UPDATE hv_mp_credits SET used=used+1 WHERE member_id=? AND day=? AND used < ?'); $q->execute([(int)$memberId, $day, (int)$quota]);
    return $q->rowCount() === 1;
}
/* Is the owner of a premium greeting still on a paid plan? (premium links lock when the plan ends) */
function mp_owner_active(PDO $pdo, $memberId){ return $memberId && mp_current_sub($pdo, $memberId) !== null; }

/* Keep hv_members.plan / plan_until in step (used by the account pages and older code). */
function mp_sync_member(PDO $pdo, $memberId){
    $s = mp_current_sub($pdo, $memberId);
    $pdo->prepare('UPDATE hv_members SET plan=?, plan_until=? WHERE id=?')->execute([$s ? $s['plan'] : 'free', $s ? substr($s['ends_at'], 0, 10) : null, (int)$memberId]);
}

/* ---------------------------------------------------------------- orders */
function mp_order_statuses(){
    return ['awaiting_payment' => 'Awaiting payment', 'verification_pending' => 'Verification pending', 'provisional' => 'Active (provisional)',
            'active' => 'Verified & active', 'rejected' => 'Rejected', 'expired' => 'Expired', 'cancelled' => 'Cancelled', 'refunded' => 'Refunded'];
}
function mp_order_by_code(PDO $pdo, $code, $memberId = null){
    $sql = 'SELECT * FROM hv_member_upgrades WHERE code=?' . ($memberId ? ' AND member_id=?' : '') . ' LIMIT 1';
    $q = $pdo->prepare($sql); $q->execute($memberId ? [$code, (int)$memberId] : [$code]); return $q->fetch(PDO::FETCH_ASSOC) ?: null;
}
function mp_order_create(PDO $pdo, array $m, $planKey, $source = 'web'){
    $p = mp_plan($pdo, $planKey); if (!$p || $planKey === 'free' || $p['status'] !== 'active') return null;
    if (strpos($planKey, 'bf') === 0 && !mp_bf_on($pdo)) return null;
    $q = $pdo->prepare("SELECT * FROM hv_member_upgrades WHERE member_id=? AND plan=? AND status='awaiting_payment' AND created_at>=? ORDER BY id DESC LIMIT 1");
    $q->execute([(int)$m['id'], $planKey, mp_add_days(mp_now(), -3)]); $o = $q->fetch(PDO::FETCH_ASSOC); if ($o) return $o;
    for ($i = 0; $i < 5; $i++) { $code = ac_upgrade_code();
        try { $pdo->prepare("INSERT INTO hv_member_upgrades (code, member_id, plan, months, amount, quota, source, status, created_at, updated_at) VALUES (?,?,?,1,?,?,?,'awaiting_payment',?,?)")
                ->execute([$code, (int)$m['id'], $planKey, $p['price'], $p['daily_quota'], $source, mp_now(), mp_now()]); break; } catch (Throwable $e) { if ($i === 4) return null; } }
    $o = mp_order_by_code($pdo, $code); mp_audit($pdo, 'order_created', ['member' => $m['id'], 'order' => $o['id']], $p['name'] . ' · ₹' . $p['price'] . ' · ' . $source);
    if (is_file(__DIR__ . '/ref.php')) { try { require_once __DIR__ . '/ref.php'; ref_attach($pdo, $o, $m); } catch (Throwable $e) { error_log('ref_attach: ' . $e->getMessage()); } }
    return $o;
}

/* Normalise what a member typed. Returns [utr, amount, paidOn, errors[]] */
function mp_parse_payment(PDO $pdo, array $o, $utr, $amount, $paidOn){
    $err = []; $utr = preg_replace('/\s+/', '', (string)$utr);
    if (!preg_match('/^\d{12}$/', $utr)) $err['utr'] = 'Enter the 12-digit UPI reference (UTR) from your payment app.';
    $amt = (int)round((float)preg_replace('/[^\d.]/', '', (string)$amount));
    if ($amt !== (int)$o['amount']) $err['amount'] = 'The amount paid must be exactly ₹' . number_format((int)$o['amount']) . ' for this plan.';
    $ts = 0; $paidOn = trim((string)$paidOn);
    if ($paidOn !== '') { try { $ts = (new DateTime(str_replace('T', ' ', $paidOn), mp_tz()))->getTimestamp(); } catch (Throwable $e) { $ts = 0; } }
    $win = max(1, (int)mp_set($pdo, 'mp_pay_window_hours')) * 3600; $now = time();
    if (!$ts) $err['paid_on'] = 'Enter the date and time of the payment.';
    elseif ($ts > $now + 600) $err['paid_on'] = 'The payment time cannot be in the future.';
    elseif ($ts < $now - $win) $err['paid_on'] = 'This payment is older than ' . ($win / 3600) . ' hours. Please message us on WhatsApp and we will check it for you.';
    elseif ($ts < mp_ts($o['created_at']) - 3600) $err['paid_on'] = 'The payment was made before this order was created. Please check the date, or message us on WhatsApp.';
    return [$utr, $amt, $ts ? (new DateTime('@' . $ts))->setTimezone(mp_tz())->format('Y-m-d H:i:s') : null, $err];
}
function mp_utr_taken(PDO $pdo, $utr, $orderId){ $q = $pdo->prepare("SELECT COUNT(*) FROM hv_member_upgrades WHERE upi_ref=? AND id<>? AND status NOT IN ('rejected')"); $q->execute([$utr, (int)$orderId]); return (int)$q->fetchColumn() > 0; }

/* Save a payment proof image (jpg/png/webp) outside the public uploads, behind the protected folder. Returns relative path or null. */
function mp_store_proof(PDO $pdo, $bin, $orderCode){
    if ($bin === null || $bin === '') return null;
    $max = max(200, (int)mp_set($pdo, 'mp_proof_max_kb')) * 1024; if (strlen($bin) > $max) return false;
    $info = @getimagesizefromstring($bin); if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)) return false;
    $ext = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'][$info[2]];
    $dir = dirname(__DIR__) . '/ac-core/cache/proofs'; if (!is_dir($dir)) @mkdir($dir, 0755, true);
    if (!is_file($dir . '/.htaccess')) @file_put_contents($dir . '/.htaccess', "Require all denied\n");
    $name = preg_replace('/[^A-Z0-9-]/', '', $orderCode) . '-' . bin2hex(random_bytes(6)) . '.' . $ext;
    return @file_put_contents($dir . '/' . $name, $bin) ? 'proofs/' . $name : false;
}

/* The member reports a payment. Starts the plan provisionally when every check passes.
   Returns ['ok'=>bool, 'error'=>string, 'fields'=>[], 'state'=>'provisional'|'pending', 'sub'=>row] */
function mp_submit_payment(PDO $pdo, array $o, $utr, $amount, $paidOn, $proofBin = null, $source = 'web', $actor = 'member'){
    mp_migrate($pdo);
    if (!in_array($o['status'], ['awaiting_payment', 'rejected'], true)) return ['ok' => false, 'error' => 'This order already has a payment reference.'];
    [$utr, $amt, $paid, $err] = mp_parse_payment($pdo, $o, $utr, $amount, $paidOn);
    if (!$err && mp_utr_taken($pdo, $utr, $o['id'])) $err['utr'] = 'This UTR has already been used for another order. If you think this is a mistake, message us on WhatsApp.';
    if ($err) { mp_audit($pdo, 'payment_rejected_input', ['member' => $o['member_id'], 'order' => $o['id']], implode(' ', array_keys($err)), $actor); return ['ok' => false, 'error' => reset($err), 'fields' => $err]; }
    $proof = null; if ($proofBin !== null && $proofBin !== '') { $proof = mp_store_proof($pdo, $proofBin, $o['code']); if ($proof === false) return ['ok' => false, 'error' => 'The screenshot must be a JPG, PNG or WebP image under ' . round((int)mp_set($pdo, 'mp_proof_max_kb') / 1024, 1) . ' MB.', 'fields' => ['proof' => 1]]; }
    $m = $pdo->prepare('SELECT * FROM hv_members WHERE id=?'); $m->execute([(int)$o['member_id']]); $m = $m->fetch(PDO::FETCH_ASSOC);
    if (!$m || $m['status'] !== 'active') return ['ok' => false, 'error' => 'This account cannot be upgraded right now. Please message us on WhatsApp.'];
    /* provisional start allowed? */
    $why = '';
    if (mp_set($pdo, 'mp_provisional') !== '1') $why = 'provisional activation is switched off';
    elseif (!empty($m['mp_blocked'])) $why = 'account had a cancelled provisional plan';
    else { $q = $pdo->prepare("SELECT COUNT(*) FROM hv_mp_subs WHERE member_id=? AND status='provisional' AND ends_at>?"); $q->execute([(int)$m['id'], mp_now()]); if ((int)$q->fetchColumn() > 0) $why = 'another provisional plan is still unconfirmed'; }
    $pdo->beginTransaction();
    try {
        $lock = $pdo->prepare('SELECT status FROM hv_member_upgrades WHERE id=? FOR UPDATE'); $lock->execute([(int)$o['id']]);
        if (!in_array($lock->fetchColumn(), ['awaiting_payment', 'rejected'], true)) { $pdo->rollBack(); return ['ok' => false, 'error' => 'This order already has a payment reference.']; }
        if (mp_utr_taken($pdo, $utr, $o['id'])) { $pdo->rollBack(); return ['ok' => false, 'error' => 'This UTR has already been used for another order.', 'fields' => ['utr' => 1]]; }
        $state = $why === '' ? 'provisional' : 'verification_pending';
        $pdo->prepare('UPDATE hv_member_upgrades SET upi_ref=?, upi_ref_at=?, paid_amount=?, paid_on=?, proof=COALESCE(?, proof), source=?, status=?, note=NULL, updated_at=? WHERE id=?')
            ->execute([$utr, mp_now(), $amt, $paid, $proof, $source, $state, mp_now(), (int)$o['id']]);
        $sub = null;
        if ($state === 'provisional') $sub = mp_start_sub($pdo, $m, $o, $paid, 'provisional', 'upi_provisional');
        $pdo->commit();
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); error_log('mp_submit_payment: ' . $e->getMessage()); return ['ok' => false, 'error' => 'Could not save right now. Please try again.']; }
    mp_audit($pdo, $state === 'provisional' ? 'provisional_activated' : 'payment_submitted', ['member' => $m['id'], 'order' => $o['id'], 'sub' => $sub['id'] ?? null],
        'UTR ' . $utr . ' · ₹' . $amt . ' · paid ' . $paid . ($proof ? ' · screenshot' : '') . ($why ? ' · held: ' . $why : ''), $actor);
    if (function_exists('ac_notify_admin')) ac_notify_admin($pdo, ($state === 'provisional' ? 'Plan started (provisional): ' : 'Plan payment to check: ') . $o['code'],
        $m['email'] . ' reported UTR ' . $utr . ' for ₹' . $amt . ' (' . $o['plan'] . ').' . ($state === 'provisional' ? ' Premium is on provisionally; it will be confirmed when this UTR appears in an uploaded statement.' : ' Not started automatically: ' . $why . '.'), 'upgrade_utr', '/admin/?m=dashboard&go=ac-upgrades');
    return ['ok' => true, 'state' => $state, 'sub' => $sub, 'held' => $why];
}

/* Start (or stack) a 30-day subscription. Same plan already running: the new one starts when it ends. */
function mp_start_sub(PDO $pdo, array $m, array $o, $paidOn, $status, $source){
    $p = mp_plan($pdo, $o['plan']); $days = max(1, (int)($p['days'] ?? 30)); $start = $paidOn ?: mp_now();
    $cur = mp_current_sub($pdo, $m['id']);
    if ($cur && $cur['plan'] === $o['plan'] && mp_ts($cur['ends_at']) > mp_ts($start)) $start = $cur['ends_at'];
    elseif ($cur && $cur['plan'] !== $o['plan']) { $pdo->prepare("UPDATE hv_mp_subs SET ends_at=?, note=CONCAT(COALESCE(note,''),' · replaced by ', ?), updated_at=? WHERE id=?")->execute([mp_now(), $o['code'], mp_now(), $cur['id']]); }
    $end = mp_add_days($start, $days);
    $pdo->prepare('INSERT INTO hv_mp_subs (member_id, order_id, plan, price, currency, quota, starts_at, ends_at, status, source, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([(int)$m['id'], (int)$o['id'], $o['plan'], (int)$o['amount'], 'INR', $o['quota'] === null ? ($p['daily_quota'] ?? null) : (int)$o['quota'], $start, $end, $status, $source, mp_now(), mp_now()]);
    $id = (int)$pdo->lastInsertId();
    $pdo->prepare('UPDATE hv_member_upgrades SET starts_at=?, ends_at=? WHERE id=?')->execute([$start, $end, (int)$o['id']]);
    mp_sync_member($pdo, $m['id']);
    $q = $pdo->prepare('SELECT * FROM hv_mp_subs WHERE id=?'); $q->execute([$id]); return $q->fetch(PDO::FETCH_ASSOC);
}

/* Confirm an order's payment (statement match or a person). Idempotent. */
function mp_confirm(PDO $pdo, array $o, $how, $actor, $note = ''){
    if (in_array($o['status'], ['active'], true)) return ['ok' => true, 'already' => true];
    if (!in_array($o['status'], ['provisional', 'verification_pending', 'awaiting_payment', 'rejected'], true)) return ['ok' => false, 'error' => 'Order is ' . $o['status'] . '.'];
    $m = $pdo->prepare('SELECT * FROM hv_members WHERE id=?'); $m->execute([(int)$o['member_id']]); $m = $m->fetch(PDO::FETCH_ASSOC); if (!$m) return ['ok' => false, 'error' => 'Member not found.'];
    $pdo->beginTransaction();
    try {
        $q = $pdo->prepare('SELECT * FROM hv_mp_subs WHERE order_id=? ORDER BY id DESC LIMIT 1 FOR UPDATE'); $q->execute([(int)$o['id']]); $sub = $q->fetch(PDO::FETCH_ASSOC);
        if ($sub && in_array($sub['status'], ['provisional', 'active'], true)) $pdo->prepare("UPDATE hv_mp_subs SET status='active', source=?, updated_at=? WHERE id=?")->execute([$how, mp_now(), $sub['id']]);
        elseif (!$sub || $sub['status'] !== 'expired') $sub = mp_start_sub($pdo, $m, $o, $o['paid_on'] ?: mp_now(), 'active', $how);
        $pdo->prepare("UPDATE hv_member_upgrades SET status='active', verified_by=?, verified_at=?, recon=?, recon_at=?, note=?, updated_at=? WHERE id=?")
            ->execute([$actor, mp_now(), $how, mp_now(), $note !== '' ? mb_substr($note, 0, 250) : null, mp_now(), (int)$o['id']]);
        $pdo->commit();
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); error_log('mp_confirm: ' . $e->getMessage()); return ['ok' => false, 'error' => 'Could not confirm.']; }
    mp_sync_member($pdo, $m['id']);
    mp_audit($pdo, 'payment_verified', ['member' => $m['id'], 'order' => $o['id'], 'sub' => $sub['id'] ?? null], $how . ($note ? ' · ' . $note : ''), $actor);
    if (is_file(__DIR__ . '/ref.php')) { try { require_once __DIR__ . '/ref.php'; ref_credit($pdo, $o); } catch (Throwable $e) { error_log('ref_credit: ' . $e->getMessage()); } }
    return ['ok' => true];
}

/* Cancel / reject / refund. Premium locks at once. $block stops future provisional starts for this member. */
function mp_end_order(PDO $pdo, array $o, $state, $actor, $note = '', $block = false){
    if (!in_array($state, ['rejected', 'cancelled', 'refunded'], true)) return false;
    $pdo->prepare('UPDATE hv_member_upgrades SET status=?, note=?, verified_by=?, verified_at=?, updated_at=? WHERE id=?')->execute([$state, mb_substr($note ?: ucfirst($state), 0, 250), $actor, mp_now(), mp_now(), (int)$o['id']]);
    $pdo->prepare("UPDATE hv_mp_subs SET status=?, ends_at=LEAST(ends_at, ?), note=CONCAT(COALESCE(note,''), ' · ', ?), updated_at=? WHERE order_id=? AND status IN ('provisional','active')")
        ->execute([$state === 'refunded' ? 'refunded' : 'cancelled', mp_now(), mb_substr($note ?: $state, 0, 100), mp_now(), (int)$o['id']]);
    if ($block) $pdo->prepare('UPDATE hv_members SET mp_blocked=1 WHERE id=?')->execute([(int)$o['member_id']]);
    mp_sync_member($pdo, $o['member_id']);
    mp_audit($pdo, 'order_' . $state, ['member' => $o['member_id'], 'order' => $o['id']], $note . ($block ? ' · provisional blocked' : ''), $actor);
    if (is_file(__DIR__ . '/ref.php')) { try { require_once __DIR__ . '/ref.php'; ref_void($pdo, $o); } catch (Throwable $e) {} }
    return true;
}

/* ---------------------------------------------------------------- statement reconciliation */
/* Parse a bank / UPI statement (CSV or pasted text). Each line: any 12-digit number is a UTR candidate,
   the amount is the number with paise (or the largest plain number that matches a plan price). */
function mp_parse_statement($text){
    $rows = []; $prices = [];
    foreach (preg_split('/\r\n|\r|\n/', (string)$text) as $line) {
        $line = trim($line); if ($line === '' || !preg_match_all('/(?<!\d)(\d{12})(?!\d)/', $line, $u)) continue;
        $amt = null; $clean = preg_replace('/(?<!\d)\d{12,}(?!\d)/', ' ', $line);
        if (preg_match_all('/(?:₹|rs\.?|inr)?\s*(\d{1,3}(?:,\d{2,3})*(?:\.\d{1,2})|\d+\.\d{1,2})/i', $clean, $a)) { foreach ($a[1] as $v) { $n = (float)str_replace(',', '', $v); if ($n > 0 && $n < 1000000) { $amt = $n; break; } } }
        $when = null; if (preg_match('/(\d{1,2})[\/\-. ](\d{1,2}|[A-Za-z]{3})[\/\-. ](\d{2,4})/', $line, $d)) { $ts = strtotime(str_replace(['/', '.'], '-', $d[0])); if ($ts) $when = date('Y-m-d H:i:s', $ts); }
        foreach (array_unique($u[1]) as $utr) $rows[] = ['utr' => $utr, 'amount' => $amt, 'txn_at' => $when, 'raw' => mb_substr($line, 0, 250)];
    }
    return $rows;
}
function mp_import_statement(PDO $pdo, $text, $actor){
    mp_migrate($pdo); $batch = 'S' . mp_now('ymdHis'); $rows = mp_parse_statement($text); $new = 0; $matched = []; $mismatch = [];
    $ins = $pdo->prepare('INSERT IGNORE INTO hv_mp_statement (utr, amount, txn_at, raw, batch, created_at) VALUES (?,?,?,?,?,?)');
    foreach ($rows as $r) { $ins->execute([$r['utr'], $r['amount'], $r['txn_at'], $r['raw'], $batch, mp_now()]); $new += $ins->rowCount(); }
    /* match every open order that has a UTR against everything ever imported */
    $open = $pdo->query("SELECT u.* FROM hv_member_upgrades u WHERE u.upi_ref IS NOT NULL AND u.status IN ('provisional','verification_pending')")->fetchAll(PDO::FETCH_ASSOC);
    $st = $pdo->prepare('SELECT * FROM hv_mp_statement WHERE utr=? LIMIT 1');
    foreach ($open as $o) {
        $st->execute([$o['upi_ref']]); $s = $st->fetch(PDO::FETCH_ASSOC); if (!$s) continue;
        if ($s['amount'] !== null && (int)round((float)$s['amount']) !== (int)$o['amount']) { $mismatch[] = $o['code'] . ' (statement ₹' . (float)$s['amount'] . ', plan ₹' . (int)$o['amount'] . ')'; $pdo->prepare("UPDATE hv_member_upgrades SET recon='amount_mismatch', recon_at=? WHERE id=?")->execute([mp_now(), $o['id']]); continue; }
        $r = mp_confirm($pdo, $o, 'statement', $actor, 'Matched statement ' . $s['batch']); if (!empty($r['ok'])) { $matched[] = $o['code']; $pdo->prepare('UPDATE hv_mp_statement SET matched_order=? WHERE id=?')->execute([$o['id'], $s['id']]); }
    }
    mp_audit($pdo, 'statement_imported', [], $batch . ' · ' . count($rows) . ' rows, ' . $new . ' new, ' . count($matched) . ' matched', $actor);
    return ['batch' => $batch, 'rows' => count($rows), 'new' => $new, 'matched' => $matched, 'mismatch' => $mismatch];
}

/* ---------------------------------------------------------------- daily upkeep: expiry + reminders */
function mp_housekeeping(PDO $pdo, $force = false){
    mp_migrate($pdo);
    $stamp = mp_now('Y-m-d H'); if (!$force && (string)setting_value($pdo, 'mp_hk_hour', '') === $stamp) return; site_settings_save($pdo, ['mp_hk_hour' => $stamp]);
    $now = mp_now();
    $ex = $pdo->prepare("SELECT * FROM hv_mp_subs WHERE status IN ('provisional','active') AND ends_at<=?"); $ex->execute([$now]);
    foreach ($ex->fetchAll(PDO::FETCH_ASSOC) as $s) {
        $pdo->prepare("UPDATE hv_mp_subs SET status='expired', updated_at=? WHERE id=?")->execute([$now, $s['id']]);
        if ($s['status'] === 'active') $pdo->prepare("UPDATE hv_member_upgrades SET status='expired', updated_at=? WHERE id=? AND status='active'")->execute([$now, $s['order_id']]);
        mp_sync_member($pdo, $s['member_id']); mp_audit($pdo, 'entitlement_expired', ['member' => $s['member_id'], 'sub' => $s['id'], 'order' => $s['order_id']], $s['plan'] . ($s['status'] === 'provisional' ? ' (never confirmed)' : ''));
        if (function_exists('ix_event')) ix_event($pdo, 'entitlement_expired', 'membership', ['detail' => $s['plan']]);
    }
    /* reminders before the end date */
    $days = array_filter(array_map('intval', explode(',', mp_set($pdo, 'mp_remind_days'))));
    if ($days && function_exists('ac_mail')) foreach ($days as $d) {
        $q = $pdo->prepare("SELECT s.*, m.email, m.name FROM hv_mp_subs s JOIN hv_members m ON m.id=s.member_id WHERE s.status IN ('provisional','active') AND s.ends_at>? AND s.ends_at<=? AND (s.reminded IS NULL OR FIND_IN_SET(?, s.reminded)=0)");
        $q->execute([$now, mp_add_days($now, $d), (string)$d]);
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $s) {
            $nx = $pdo->prepare("SELECT COUNT(*) FROM hv_mp_subs WHERE member_id=? AND id<>? AND status IN ('provisional','active') AND starts_at>=?"); $nx->execute([$s['member_id'], $s['id'], $s['ends_at']]); if ((int)$nx->fetchColumn()) { $pdo->prepare("UPDATE hv_mp_subs SET reminded=CONCAT_WS(',', reminded, ?) WHERE id=?")->execute([(string)$d, $s['id']]); continue; }
            $p = mp_plan($pdo, $s['plan']);
            ac_mail($pdo, $s['email'], 'Your H View ' . ($p['name'] ?? '') . ' plan ends on ' . mp_fmt($s['ends_at'], 'j M'), '<p>Hi ' . e($s['name']) . ',</p><p>Your <b>' . e($p['name'] ?? $s['plan']) . '</b> plan ends on <b>' . e(mp_fmt($s['ends_at'], 'j M Y, g:i a')) . ' IST</b>. Plans do not renew automatically. After it ends, premium designs lock — including premium greetings you have shared — and your free designs keep working.</p><p><a href="https://hview.in/account/plan/">Renew your plan</a></p>');
            $pdo->prepare("UPDATE hv_mp_subs SET reminded=CONCAT_WS(',', reminded, ?) WHERE id=?")->execute([(string)$d, $s['id']]);
            mp_audit($pdo, 'renewal_reminder', ['member' => $s['member_id'], 'sub' => $s['id']], $d . ' day(s) before');
        }
    }
    /* orders left unpaid for 7 days */
    $pdo->prepare("UPDATE hv_member_upgrades SET status='cancelled', note='Not paid within 7 days', updated_at=? WHERE status='awaiting_payment' AND created_at<?")->execute([$now, mp_add_days($now, -7)]);
    /* old credit rows */
    $pdo->prepare('DELETE FROM hv_mp_credits WHERE day<?')->execute([substr(mp_add_days($now, -60), 0, 10)]);
}

/* ---------------------------------------------------------------- numbers for the admin */
function mp_stats(PDO $pdo){
    mp_migrate($pdo); $now = mp_now(); $v = function ($sql, $a = []) use ($pdo) { $q = $pdo->prepare($sql); $q->execute($a); return $q->fetchColumn(); };
    return [
        'active' => (int)$v("SELECT COUNT(DISTINCT member_id) FROM hv_mp_subs WHERE status='active' AND starts_at<=? AND ends_at>?", [$now, $now]),
        'provisional' => (int)$v("SELECT COUNT(DISTINCT member_id) FROM hv_mp_subs WHERE status='provisional' AND ends_at>?", [$now]),
        'held' => (int)$v("SELECT COUNT(*) FROM hv_member_upgrades WHERE status='verification_pending'"),
        'unpaid' => (int)$v("SELECT COUNT(*) FROM hv_member_upgrades WHERE status='awaiting_payment'"),
        'revenue_verified' => (int)$v("SELECT COALESCE(SUM(amount),0) FROM hv_member_upgrades WHERE status IN ('active','expired') AND recon IS NOT NULL"),
        'revenue_provisional' => (int)$v("SELECT COALESCE(SUM(amount),0) FROM hv_member_upgrades WHERE status='provisional'"),
        'expiring7' => (int)$v("SELECT COUNT(*) FROM hv_mp_subs WHERE status IN ('provisional','active') AND ends_at>? AND ends_at<=?", [$now, mp_add_days($now, 7)]),
        'unmatched_old' => (int)$v("SELECT COUNT(*) FROM hv_member_upgrades WHERE status='provisional' AND upi_ref_at<?", [mp_add_days($now, -(int)mp_set($pdo, 'mp_recon_grace_days'))]),
    ];
}

/* Are any premium designs actually live? Plans are only sold once there is something to unlock. */
function mp_premium_live(PDO $pdo){
    static $n = null; if ($n !== null) return $n;
    try { $f = dirname(__DIR__) . '/ix-core/lib.php'; if (is_file($f)) { require_once $f; $n = 0; foreach (ix_live($pdo) as $p) foreach ($p['designs_on'] as $d) if (($p['tiers'][$d] ?? 'free') === 'premium') $n++; return $n; } } catch (Throwable $e) {}
    return $n = 0;
}

/* "₹199/month" for monthly plans, "₹49 for 48 hours" for short passes (update 54) */
function mp_price_label(array $p){
    $d = (int)($p['days'] ?? 30); $amt = '₹' . number_format((int)$p['price']);
    if ($d >= 28) return $amt . '/month';
    return $amt . ' for ' . ($d <= 3 ? ($d * 24) . ' hours' : $d . ' days');
}
function mp_period_label(array $p){ $d = (int)($p['days'] ?? 30); return $d >= 28 ? $d . ' days' : ($d <= 3 ? ($d * 24) . ' hours' : $d . ' days'); }

