<?php
/* =====================================================================
 * H View referral wallet (r78, 25 Nov 2026)
 * - Only members who have bought a plan see it (Account → Refer & earn). Never shown on public pages or pop-ups.
 * - Their private link is /account/plan/?ref=CODE. A friend who buys through it within 30 days earns them
 *   ref_rate % (default 20) of what the friend paid, once H View has confirmed that payment.
 * - Earnings wait ref_hold_days (default 7) in "pending" in case a payment is reversed, then become available.
 * - At ref_min_payout (default ₹500) or more, the member asks for a withdrawal to their UPI ID.
 *   The team pays it by hand and marks it paid in Control Center → Referral wallet.
 * - No commission on your own purchase; buys from the same network are flagged for a look.
 * Amounts are stored in paise.
 * ===================================================================== */
function ref_set(PDO $pdo, $k){
    $d = ['ref_on' => '1', 'ref_rate' => '20', 'ref_min_payout' => '500', 'ref_hold_days' => '7'];
    return (string)setting_value($pdo, $k, $d[$k] ?? '');
}
function ref_now(){ return function_exists('mp_now') ? mp_now() : date('Y-m-d H:i:s'); }
function ref_migrate(PDO $pdo){
    static $done = false; if ($done) return; $done = true;
    if ((string)setting_value($pdo, 'ref_schema', '') === '1') return;
    $cs = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $pdo->exec("CREATE TABLE IF NOT EXISTS hv_ref_codes (member_id INT UNSIGNED NOT NULL PRIMARY KEY, code VARCHAR(12) NOT NULL UNIQUE, created_at DATETIME NOT NULL) $cs");
    $pdo->exec("CREATE TABLE IF NOT EXISTS hv_ref_earnings (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, referrer_id INT UNSIGNED NOT NULL, order_id INT UNSIGNED NOT NULL UNIQUE,
        buyer_id INT UNSIGNED NOT NULL, plan VARCHAR(12) NOT NULL, amount INT NOT NULL, commission INT NOT NULL, status VARCHAR(10) NOT NULL DEFAULT 'pending',
        flag VARCHAR(80) NULL, available_at DATETIME NOT NULL, created_at DATETIME NOT NULL, INDEX(referrer_id, status)) $cs");
    $pdo->exec("CREATE TABLE IF NOT EXISTS hv_ref_payouts (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, member_id INT UNSIGNED NOT NULL, amount INT NOT NULL,
        upi VARCHAR(80) NOT NULL, status VARCHAR(10) NOT NULL DEFAULT 'requested', note VARCHAR(255) NULL, utr VARCHAR(40) NULL,
        created_at DATETIME NOT NULL, paid_at DATETIME NULL, INDEX(member_id), INDEX(status)) $cs");
    try { $q = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'hv_member_upgrades' AND COLUMN_NAME = 'ref_by'");
          if (!(int)$q->fetchColumn()) $pdo->exec('ALTER TABLE hv_member_upgrades ADD COLUMN ref_by INT UNSIGNED NULL'); } catch (Throwable $e) {}
    site_settings_save($pdo, ['ref_schema' => '1']);
}
function ref_rupees($paise){ $p = (int)$paise; return '₹' . number_format(intdiv($p, 100)) . ($p % 100 ? '.' . str_pad((string)($p % 100), 2, '0', STR_PAD_LEFT) : ''); }

/* Members who have bought at least one plan (paid or being confirmed). */
function ref_eligible(PDO $pdo, array $m){
    if (ref_set($pdo, 'ref_on') !== '1') return false;
    static $c = []; $id = (int)$m['id']; if (isset($c[$id])) return $c[$id];
    try { $q = $pdo->prepare("SELECT COUNT(*) FROM hv_member_upgrades WHERE member_id=? AND amount>0 AND status IN ('active','provisional','verification_pending')"); $q->execute([$id]); return $c[$id] = (int)$q->fetchColumn() > 0; }
    catch (Throwable $e) { return $c[$id] = false; }
}
function ref_code(PDO $pdo, $memberId){
    ref_migrate($pdo);
    $q = $pdo->prepare('SELECT code FROM hv_ref_codes WHERE member_id=?'); $q->execute([(int)$memberId]); $c = $q->fetchColumn(); if ($c) return (string)$c;
    $a = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    for ($i = 0; $i < 6; $i++) { $c = 'HV'; for ($j = 0; $j < 6; $j++) $c .= $a[random_int(0, strlen($a) - 1)];
        try { $pdo->prepare('INSERT INTO hv_ref_codes (member_id, code, created_at) VALUES (?,?,?)')->execute([(int)$memberId, $c, ref_now()]); return $c; } catch (Throwable $e) {} }
    return '';
}
function ref_link(PDO $pdo, $memberId){ $c = ref_code($pdo, $memberId); return $c !== '' ? rtrim((string)setting_value($pdo, 'site_url', 'https://hview.in'), '/') . '/account/plan/?ref=' . $c : ''; }

/* Remember who sent this visitor (30 days). Called on /account/ pages that carry ?ref= */
function ref_capture(){
    $c = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)($_GET['ref'] ?? '')));
    if (strlen($c) < 6 || strlen($c) > 12) return;
    setcookie('hv_ref', $c, ['expires' => time() + 30 * 86400, 'path' => '/', 'secure' => true, 'httponly' => true, 'samesite' => 'Lax']);
    $_COOKIE['hv_ref'] = $c;
}
/* On a new order: note the referrer, unless it is the buyer. */
function ref_attach(PDO $pdo, array $o, array $buyer){
    $c = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)($_COOKIE['hv_ref'] ?? ''))); if ($c === '' || !empty($o['ref_by'])) return;
    ref_migrate($pdo);
    $q = $pdo->prepare('SELECT member_id FROM hv_ref_codes WHERE code=?'); $q->execute([$c]); $rid = (int)$q->fetchColumn();
    if (!$rid || $rid === (int)$buyer['id']) return;
    $pdo->prepare('UPDATE hv_member_upgrades SET ref_by=? WHERE id=? AND ref_by IS NULL')->execute([$rid, (int)$o['id']]);
}
/* After H View confirms a payment: credit the referrer. Idempotent (one earning per order). */
function ref_credit(PDO $pdo, array $o){
    ref_migrate($pdo);
    $q = $pdo->prepare('SELECT * FROM hv_member_upgrades WHERE id=?'); $q->execute([(int)$o['id']]); $o = $q->fetch(PDO::FETCH_ASSOC);
    if (!$o || empty($o['ref_by']) || (int)$o['ref_by'] === (int)$o['member_id']) return;
    $paid = (int)($o['paid_amount'] ?: $o['amount']); if ($paid <= 0) return;
    $com = (int)round($paid * 100 * (float)ref_set($pdo, 'ref_rate') / 100);
    $flag = null;
    try { $m = $pdo->prepare('SELECT id, last_ip_hash FROM hv_members WHERE id IN (?,?)'); $m->execute([(int)$o['ref_by'], (int)$o['member_id']]); $ips = array_column($m->fetchAll(PDO::FETCH_ASSOC), 'last_ip_hash');
          if (count($ips) === 2 && $ips[0] && $ips[0] === $ips[1]) $flag = 'Buyer and referrer used the same network'; } catch (Throwable $e) {}
    $avail = date('Y-m-d H:i:s', strtotime(ref_now()) + 86400 * max(0, (int)ref_set($pdo, 'ref_hold_days')));
    $pdo->prepare('INSERT IGNORE INTO hv_ref_earnings (referrer_id, order_id, buyer_id, plan, amount, commission, status, flag, available_at, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)')
        ->execute([(int)$o['ref_by'], (int)$o['id'], (int)$o['member_id'], $o['plan'], $paid, $com, 'pending', $flag, $avail, ref_now()]);
}
/* Payment rejected / refunded: take the commission back if it was not paid out yet. */
function ref_void(PDO $pdo, array $o){
    ref_migrate($pdo);
    $pdo->prepare("UPDATE hv_ref_earnings SET status='void' WHERE order_id=? AND status='pending'")->execute([(int)$o['id']]);
}
function ref_wallet(PDO $pdo, $memberId){
    ref_migrate($pdo); $now = ref_now(); $id = (int)$memberId;
    $q = $pdo->prepare("SELECT COALESCE(SUM(CASE WHEN available_at<=? THEN commission END),0) ready, COALESCE(SUM(CASE WHEN available_at>? THEN commission END),0) waiting, COUNT(*) n FROM hv_ref_earnings WHERE referrer_id=? AND status='pending'");
    $q->execute([$now, $now, $id]); $e = $q->fetch(PDO::FETCH_ASSOC);
    $q = $pdo->prepare("SELECT COALESCE(SUM(CASE WHEN status='requested' THEN amount END),0) asked, COALESCE(SUM(CASE WHEN status='paid' THEN amount END),0) paid FROM hv_ref_payouts WHERE member_id=?");
    $q->execute([$id]); $p = $q->fetch(PDO::FETCH_ASSOC);
    $earned = $pdo->prepare("SELECT COALESCE(SUM(commission),0) FROM hv_ref_earnings WHERE referrer_id=? AND status<>'void'"); $earned->execute([$id]);
    $total = (int)$earned->fetchColumn();
    $available = max(0, $total - (int)$e['waiting'] - (int)$p['asked'] - (int)$p['paid']);
    return ['available' => $available, 'waiting' => (int)$e['waiting'], 'requested' => (int)$p['asked'], 'paid' => (int)$p['paid'], 'total' => $total, 'min' => 100 * (int)ref_set($pdo, 'ref_min_payout')];
}

/* ---------------------------------------------------------------- member page: /account/wallet/ */
function ref_post(PDO $pdo, array $m){
    if (!ac_csrf_ok()) { ac_flash('error', 'Your session expired. Please try again.'); ac_go('/account/wallet/'); }
    if (!ref_eligible($pdo, $m)) ac_go('/account/');
    if ((string)($_POST['do'] ?? '') === 'withdraw') {
        $upi = trim((string)($_POST['upi'] ?? ''));
        if (!preg_match('/^[A-Za-z0-9._-]{2,64}@[A-Za-z]{2,32}$/', $upi)) { ac_flash('error', 'Enter a UPI ID like name@okbank.'); ac_go('/account/wallet/'); }
        $w = ref_wallet($pdo, $m['id']);
        if ($w['requested'] > 0) { ac_flash('info', 'Your earlier withdrawal is still being processed.'); ac_go('/account/wallet/'); }
        if ($w['available'] < $w['min']) { ac_flash('error', 'You can withdraw once ' . ref_rupees($w['min']) . ' is available.'); ac_go('/account/wallet/'); }
        $pdo->prepare('INSERT INTO hv_ref_payouts (member_id, amount, upi, status, created_at) VALUES (?,?,?,?,?)')->execute([(int)$m['id'], $w['available'], $upi, 'requested', ref_now()]);
        if (function_exists('ac_notify_admin')) { try { ac_notify_admin($pdo, 'Referral withdrawal: ' . ref_rupees($w['available']), $m['name'] . ' asked for ' . ref_rupees($w['available']) . ' to ' . $upi . '.', 'member_signup', '/admin/?m=dashboard&go=referrals'); } catch (Throwable $e) {} }
        ac_flash('success', 'Withdrawal requested: ' . ref_rupees($w['available']) . ' to ' . $upi . '. We usually pay within 3 working days.');
    }
    ac_go('/account/wallet/');
}
function ref_render(PDO $pdo, array $m){
    if (!ref_eligible($pdo, $m)) { echo '<section class="acx-card"><h2>Refer &amp; earn</h2><p class="acx-muted">This opens after your first plan purchase.</p><a class="acx-btn acx-btn-primary" href="/account/plan/">See plans</a></section>'; return; }
    $w = ref_wallet($pdo, $m['id']); $link = ref_link($pdo, $m['id']); $rate = (int)ref_set($pdo, 'ref_rate');
    $rows = $pdo->prepare('SELECT plan, amount, commission, status, available_at, created_at FROM hv_ref_earnings WHERE referrer_id=? ORDER BY id DESC LIMIT 50'); $rows->execute([(int)$m['id']]); $rows = $rows->fetchAll(PDO::FETCH_ASSOC);
    $pays = $pdo->prepare('SELECT amount, upi, status, created_at, paid_at, utr FROM hv_ref_payouts WHERE member_id=? ORDER BY id DESC LIMIT 20'); $pays->execute([(int)$m['id']]); $pays = $pays->fetchAll(PDO::FETCH_ASSOC);
    $plans = function_exists('mp_plans') ? mp_plans($pdo, true) : [];
    $pct = $w['min'] > 0 ? min(100, (int)round($w['available'] / $w['min'] * 100)) : 100; ?>
<section class="acx-card rf-hero">
  <p class="acx-kicker">Private to you</p>
  <h2>Earn <?=$rate?>% on every plan a friend buys</h2>
  <p class="acx-muted">Share your link. When someone buys any H View plan through it, <b><?=$rate?>% of what they pay</b> goes into your wallet, for example <b><?=ref_rupees(19900 * $rate / 100)?></b> on ₹199 or <b><?=ref_rupees(49900 * $rate / 100)?></b> on ₹499. Withdraw to UPI once you reach <b><?=ref_rupees($w['min'])?></b>.</p>
  <div class="rf-link"><input id="rf-link" value="<?=e($link)?>" readonly aria-label="Your referral link"><button type="button" class="acx-btn acx-btn-primary" data-rf-copy>Copy link</button>
    <a class="acx-btn" href="https://wa.me/?text=<?=rawurlencode('I use H View for premium birthday wishes, invitations and tools. Get it here: ' . $link)?>" target="_blank" rel="noopener">Share on WhatsApp</a></div>
</section>
<section class="rf-kpis">
  <div class="rf-kpi is-main"><small>Available to withdraw</small><b><?=ref_rupees($w['available'])?></b><span class="rf-bar"><i style="width:<?=$pct?>%"></i></span><em><?=$w['available'] >= $w['min'] ? 'Ready to withdraw' : ref_rupees($w['min'] - $w['available']) . ' more to withdraw'?></em></div>
  <div class="rf-kpi"><small>Pending (7-day check)</small><b><?=ref_rupees($w['waiting'])?></b><em>Becomes available after the hold</em></div>
  <div class="rf-kpi"><small>Withdrawn so far</small><b><?=ref_rupees($w['paid'])?></b><em><?=$w['requested'] ? ref_rupees($w['requested']) . ' being paid' : 'Paid to your UPI'?></em></div>
</section>
<div class="acx-grid2">
<section class="acx-card"><h2>Withdraw</h2>
  <?php if ($w['requested']): ?><p class="acx-flash acx-flash-info">Your withdrawal of <b><?=ref_rupees($w['requested'])?></b> is being processed. We usually pay within 3 working days.</p>
  <?php elseif ($w['available'] >= $w['min']): ?>
  <form method="post" class="acx-form"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="do" value="withdraw">
    <label class="acx-field"><span>Your UPI ID</span><input name="upi" required maxlength="80" placeholder="name@okbank" autocomplete="off"></label>
    <button class="acx-btn acx-btn-primary">Withdraw <?=ref_rupees($w['available'])?></button></form>
  <?php else: ?><p class="acx-muted">You can withdraw once <?=ref_rupees($w['min'])?> is available in your wallet.</p><?php endif ?>
  <h3 class="rf-h3">Rules</h3>
  <ul class="rf-rules"><li><?=$rate?>% of each plan bought through your link, after we confirm the payment.</li><li>Friends must open your link and buy within 30 days.</li><li>Earnings stay pending for 7 days, then become available.</li><li>Your own purchases never earn a commission.</li><li>Payments that are reversed or not received are removed from your wallet.</li><li>Withdrawals are paid by UPI, usually within 3 working days.</li></ul>
</section>
<section class="acx-card"><h2>Your earnings</h2>
  <?php if ($rows): ?><div class="acx-table"><table><thead><tr><th>Date</th><th>Plan</th><th>You earn</th><th>Status</th></tr></thead><tbody>
  <?php foreach ($rows as $r): $st = $r['status'] === 'void' ? 'Not received' : ($r['available_at'] > ref_now() ? 'Pending until ' . date('j M', strtotime($r['available_at'])) : 'Available'); ?>
    <tr><td><?=e(date('j M Y', strtotime($r['created_at'])))?></td><td><?=e($plans[$r['plan']]['name'] ?? $r['plan'])?> · <?=ac_money($r['amount'])?></td><td><b><?=ref_rupees($r['commission'])?></b></td><td><span class="acx-pill"><?=e($st)?></span></td></tr>
  <?php endforeach ?></tbody></table></div>
  <?php else: ?><p class="acx-muted">No referrals yet. Share your link with friends and family who make wishes, invitations or use our tools.</p><?php endif ?>
  <?php if ($pays): ?><h3 class="rf-h3">Withdrawals</h3><div class="acx-table"><table><tbody><?php foreach ($pays as $p): ?><tr><td><?=e(date('j M Y', strtotime($p['created_at'])))?></td><td><?=ref_rupees($p['amount'])?></td><td><?=e($p['upi'])?></td><td><span class="acx-pill"><?=e(['requested' => 'Processing', 'paid' => 'Paid', 'rejected' => 'Not paid'][$p['status']] ?? $p['status'])?></span></td></tr><?php endforeach ?></tbody></table></div><?php endif ?>
</section></div>
<style>
.rf-hero h2{margin:.2rem 0 .4rem}.rf-link{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}.rf-link input{flex:1 1 260px;min-width:0;padding:11px 12px;border:1px solid var(--line,#e4e7ec);border-radius:12px;font:inherit;background:#f8f9fc}
.rf-kpis{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin:16px 0}.rf-kpi{background:#fff;border:1px solid var(--line,#e4e7ec);border-radius:16px;padding:16px 18px;display:flex;flex-direction:column;gap:4px}
.rf-kpi small{color:var(--muted,#667085)}.rf-kpi b{font-size:1.6rem;color:var(--ink,#101828)}.rf-kpi em{font-style:normal;font-size:.85rem;color:var(--muted,#667085)}
.rf-kpi.is-main{background:linear-gradient(135deg,#1E4CFF0f,#D81B760f);border-color:#c9d2ff}.rf-bar{height:6px;background:#eef0f6;border-radius:6px;overflow:hidden}.rf-bar i{display:block;height:100%;background:linear-gradient(90deg,#1E4CFF,#6553D9,#D81B76)}
.rf-h3{margin:18px 0 8px;font-size:1rem}.rf-rules{margin:0;padding-left:18px;color:var(--muted,#667085);line-height:1.7;font-size:.92rem}
@media(max-width:720px){.rf-kpis{grid-template-columns:1fr}}
</style>
<script>document.addEventListener('click',function(e){var b=e.target.closest('[data-rf-copy]');if(!b)return;var i=document.getElementById('rf-link');i.select();try{navigator.clipboard.writeText(i.value)}catch(x){document.execCommand('copy')}b.textContent='Copied ✓';setTimeout(function(){b.textContent='Copy link'},1800)});</script>
<?php }
