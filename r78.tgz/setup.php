<?php
/* r78 data: Black Friday plans (bf3/bf6/bf8/bf12), sale end, plagiarism Pro tier for them. Safe to re-run. */
$c = require dirname(__DIR__, 2) . '/config.php';
$p = new PDO('mysql:host=' . $c['db_host'] . ';dbname=' . $c['db_name'] . ';charset=utf8mb4', $c['db_user'], $c['db_pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$now = (new DateTime('now', new DateTimeZone('Asia/Kolkata')))->format('Y-m-d H:i:s');
$ben = ['Every premium wish and invitation design, no daily limit', 'Photo-real animated surprises: gift box, secret message, 3D pop-up card and more', 'Plagiarism checker Pro: 200 checks a month, up to 15,000 words each', 'Every free tool: PDF, image, OCR and SEO tools', 'No ads anywhere on H View', 'One payment, nothing renews automatically'];
$plans = [['bf3', '3 months', 199, 90, 'Black Friday · about ₹66 a month', 101], ['bf6', '6 months', 299, 180, 'Black Friday · about ₹50 a month', 102],
          ['bf8', '8 months', 399, 240, 'Black Friday · about ₹50 a month', 103], ['bf12', '12 months', 499, 365, 'Black Friday · about ₹42 a month', 104]];
$q = $p->prepare("INSERT INTO hv_mp_plans (plan_key, name, price, currency, days, daily_quota, tagline, benefits, status, sort, updated_at) VALUES (?,?,?,'INR',?,NULL,?,?,'active',?,?)
  ON DUPLICATE KEY UPDATE name=VALUES(name), price=VALUES(price), days=VALUES(days), daily_quota=NULL, tagline=VALUES(tagline), benefits=VALUES(benefits), status='active', sort=VALUES(sort), updated_at=VALUES(updated_at)");
foreach ($plans as $x) $q->execute([$x[0], $x[1], $x[2], $x[3], $x[4], json_encode($ben, JSON_UNESCAPED_UNICODE), $x[5], $now]);
$s = $p->prepare('INSERT INTO hv_settings (setting_key, setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');
foreach (['bf_until' => '2026-11-30 23:59:59', 'mp_pc_tier_bf3' => 'pro', 'mp_pc_tier_bf6' => 'pro', 'mp_pc_tier_bf8' => 'pro', 'mp_pc_tier_bf12' => 'pro'] as $k => $v) $s->execute([$k, $v]);
echo "plans + settings ok\n";
foreach ($p->query("SELECT plan_key,name,price,days,status FROM hv_mp_plans WHERE plan_key LIKE 'bf%'") as $r) echo implode(' | ', array_slice($r, 0, 5)), "\n";
